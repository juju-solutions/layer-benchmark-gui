from pyramid.config import Configurator


def main(global_config, **settings):
    """ This function returns a Pyramid WSGI application.
    """
    config = Configurator(settings=settings)
    config.add_static_view('static', 'static', cache_max_age=3600)

    config.add_route('api_actions', '/api/actions')
    config.add_route('api_action', '/api/actions/{action}')
    config.add_route('api_benchmarks', '/api/benchmarks')
    config.add_route('api_service', '/api/services/{service}')
    config.add_route('api_unit', '/api/units/{service}/{unit}')

    config.add_route('root', '/')
    config.add_route('actions', '/actions')
    config.add_route('actions_compare', '/actions/compare')
    config.add_route('action', '/actions/{action}')
    config.add_route('action_metrics', '/actions/{action}/metrics')
    config.add_route('benchmarks', '/benchmarks')
    config.add_route('unit', '/units/{service}/{unit}')

    config.scan()
    return config.make_wsgi_app()
