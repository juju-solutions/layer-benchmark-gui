import gevent
from gevent import monkey
monkey.patch_all()

from pyramid.config import Configurator
from collectorweb.websockets import juju_api_listener

from sqlalchemy import engine_from_config
from sqlalchemy.orm import sessionmaker


def db(request):
    maker = request.registry.dbmaker
    session = maker()

    def cleanup(request):
        if request.exception is not None:
            session.rollback()
        else:
            session.commit()
        session.close()
    request.add_finished_callback(cleanup)

    return session


def main(global_config, **settings):
    """ This function returns a Pyramid WSGI application.
    """
    config = Configurator(settings=settings)

    engine = engine_from_config(settings, prefix='sqlalchemy.')
    config.registry.dbmaker = sessionmaker(bind=engine)
    config.add_request_method(db, reify=True)

    config.add_static_view('static', 'static', cache_max_age=3600)

    config.add_route('api_root', '/api')
    config.add_route('api_export', '/api/export')
    config.add_route('api_import', '/api/import')
    config.add_route('api_actions', '/api/actions')
    config.add_route('api_action', '/api/actions/{action}')
    config.add_route('api_action_cancel', '/api/actions/{action}/cancel')
    config.add_route('api_action_publish', '/api/actions/{action}/publish')
    config.add_route('api_benchmarks', '/api/benchmarks')
    config.add_route('api_service', '/api/services/{service}')
    config.add_route('api_unit', '/api/units/{service}/{unit}')
    config.add_route('api_comparison_graphs', '/api/comparisons/{id}/graphs')
    config.add_route('api_comparison_graph', '/api/comparisons/{id}/graph/{graph}')
    config.add_route('api_comparison', '/api/comparisons/{id}')

    config.add_route('root', '/')
    config.add_route('export', '/export')
    config.add_route('import', '/import')
    config.add_route('actions', '/actions')
    config.add_route('action_svg', '/actions/{action}/svg')
    config.add_route('action_metrics', '/actions/{action}/metrics')
    config.add_route('action_graphs', '/actions/{action}/graphs')
    config.add_route('action_graph', '/actions/{action}/graph/{graph}')
    config.add_route('action_tags', '/actions/{action}/tags')

    config.add_route('socket_io', 'socket.io/*remaining')
    gevent.spawn(juju_api_listener, config.registry.settings)

    config.scan()
    return config.make_wsgi_app()
