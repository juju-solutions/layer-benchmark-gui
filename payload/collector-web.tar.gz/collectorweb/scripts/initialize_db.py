import argparse
import os

from pyramid.paster import bootstrap


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('ini_file')
    args = parser.parse_args()

    env = bootstrap(os.path.abspath(args.ini_file))
    request = env['request']

    from collectorweb.models import Base
    Base.metadata.drop_all(request.db.bind)
    Base.metadata.create_all(request.db.bind)


if __name__ == '__main__':
    main()
