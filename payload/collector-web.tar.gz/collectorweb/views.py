import datetime
import difflib
import json
import re

import requests

from pyramid.response import Response
from pyramid.view import view_config
from pyramid.httpexceptions import (
    HTTPBadRequest,
    HTTPFound,
    HTTPNotFound,
    HTTPServiceUnavailable,
)

from .api import API
from .db import Redis


@view_config(route_name='root', renderer='index.mako')
def root(request):
    api = API(request)
    benchmarks = api.get_benchmarks()
    return {'benchmarks': benchmarks}


@view_config(route_name='api_root', renderer='json')
def api_root(request):
    api = API(request)
    benchmarks = {}
    results = api.get_benchmarks(request)
    for name, actions in results.items():
        benchmarks[name] = {
            "actions": actions,
            "result_keys": sorted(set(k for a in actions
                                      for k in a.results)),
        }
    return {
        'benchmarks': benchmarks,
        'settings': {
            'graphite_url': request.registry.settings['graphite.url'],
        },
        'action_specs': api.get_benchmark_action_specs(),
        'service_units': api.get_service_units(),
    }


@view_config(route_name='benchmarks', renderer='actions/index.mako')
def benchmarks(request):
    api = API(request)
    actions = api.get_benchmark_actions()
    action_specs = api.get_benchmark_action_specs()
    service_units = api.get_service_units()

    return {
        'actions': actions,
        'action_specs': action_specs,
        'service_units': service_units,
    }


@view_config(route_name='api_benchmarks', renderer='json')
def api_benchmarks(request):
    api = API(request)
    return api.get_benchmark_actions() or {}


@view_config(route_name='actions', request_method='POST')
def action_create(request):
    d = request.params
    action = d['action']
    service = d['service']
    receivers = d.getall('receivers')
    tags = d.getall('tags')

    if receivers:
        api = API(request)
        action_spec = api.get_action_specs()[service][action]

        params = {}
        for prop in [k for k in d if k.startswith('prop-')]:
            prop_name = prop[5:]  # remove 'prop-' prefix
            prop_val = action_spec.properties[prop_name].to_python(d[prop])
            params[prop_name] = prop_val

        action = api.enqueue_action(action, receivers, params)
        if tags:
            r = Redis(request)
            r.update_action_tags(action.uuid, tags)

    return HTTPFound(location=request.referer)


@view_config(route_name='actions', renderer='actions/index.mako')
def actions(request):
    api = API(request)
    actions = api.get_actions()
    action_specs = api.get_action_specs()
    service_units = api.get_service_units()

    return {
        'actions': actions,
        'action_specs': action_specs,
        'service_units': service_units,
    }


@view_config(route_name='actions_compare', renderer='actions/compare.mako')
def actions_compare(request):
    from_uuid = request.params.get('from')
    to_uuid = request.params.get('to')

    api = API(request)
    from_ = api.get_action(from_uuid)
    to_ = api.get_action(to_uuid)
    if not from_ or not to_:
        return HTTPBadRequest(
            "'from' and 'to' params are required and must contain "
            "a valid action uuid")

    r = Redis(request)

    def get_profile(action):
        return r.get_profile_data(
            action.receiver, action=from_.uuid, start=action.start,
            stop=action.stop)

    def diff(from_, to_):
        def to_lines(d):
            return json.dumps(d, indent=2).split('\n')
        differ = difflib.HtmlDiff()
        return differ.make_table(to_lines(from_), to_lines(to_))

    from_profile = get_profile(from_)
    to_profile = get_profile(to_)

    return {
        'from_': from_,
        'to_': to_,
        'from_profile': from_profile,
        'to_profile': to_profile,
        'action_diff': diff(from_, to_),
        'profile_diff': (diff(from_profile, to_profile) if
                         from_profile and to_profile else None),
        'styles': difflib._styles,
    }


@view_config(route_name='action', renderer='actions/show.mako')
def action(request):
    uuid = request.matchdict['action']

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound()

    return {'action': action}


@view_config(route_name='action_graphs', request_method='POST',
             renderer='json')
def action_graphs_post(request):
    action_uuid = request.matchdict['action']
    datapoints = json.loads(request.params['datapoints'])
    label = request.params.get('label', '')

    r = Redis(request)
    graph_uuid = r.insert_action_graph(action_uuid, datapoints, label)

    return {
        'uuid': graph_uuid,
    }


@view_config(route_name='action_graph', request_method='DELETE')
def action_graph_delete(request):
    action_uuid = request.matchdict['action']
    graph_uuid = request.matchdict['graph']

    r = Redis(request)
    r.delete_action_graph(action_uuid, graph_uuid)

    return Response()


@view_config(route_name='action_tags', request_method='PUT',
             renderer='json')
def action_tags_put(request):
    action_uuid = request.matchdict['action']
    tags = json.loads(request.params['tags'])

    r = Redis(request)
    r.update_action_tags(action_uuid, tags)

    return Response()


@view_config(route_name='action_svg', request_method='POST')
def action_svg(request):
    data = request.body
    r = requests.post('http://svg.juju.solutions', data)
    return Response(body=r.content, content_type='image/svg+xml')


@view_config(route_name='action_metrics')
def action_metrics(request):
    mime = {
        'png': 'image/png',
        'json': 'application/json',
        'raw': 'application/octet-stream',
        'csv': 'text/csv',
        'svg': 'image/svg+xml',
    }

    uuid = request.matchdict['action']
    format_ = request.params.get('format', 'json')
    if format_ not in mime:
        return HTTPBadRequest(
            'Unsupported metrics format "{}".'
            'Valid formats are: {}'.format(
                format_, ', '.join(mime.keys())))

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound('No such action')

    r = action.get_metrics(request, format_=format_)
    if not r.status_code == 200:
        return HTTPServiceUnavailable(
            "Couldn't retrieve metrics from "
            "graphite server: {}".format(r.url))

    if format_ == 'json':
        return Response(
            json.dumps(format_metrics(r.json())),
            content_type=mime[format_])

    return Response(body=r.content, content_type=mime[format_])


def format_metrics(data):
    """Convert the metric data returned by Graphite into the structure that
    we actually want to use. Example of incoming/outgoing format:

    incoming = [{
        'target': 'unit-pts-0.tvansteenburgh-local-machine-1.battery-0.charge',
        'datapoints': [[y, x]]
    }]

    outgoing = {
      'pts': {
        '0': {
          'battery-0': {
            'charge': [{'x': x, 'y': y}]
          }
        }
      }
    }

    """
    services = {}
    for metric in data:
        target_parts = metric['target'].split('.')
        receiver = target_parts[0]
        if not re.match(r'unit-[^-]+-\d+', receiver):
            continue
        _, unit = receiver.rsplit('-', 1)
        _, service = _.split('-', 1)
        metric_main, metric_sub = target_parts[-2:]
        start_time = min(sorted([x for y, x in metric['datapoints']]))
        datapoints = [dict(x=x - start_time, y=y)
                      for y, x in metric['datapoints']]

        if service in services:
            if unit in services[service]:
                if metric_main in services[service][unit]:
                    if metric_sub in services[service][unit][metric_main]:
                        services[service][unit][metric_main][metric_sub].extend(datapoints)
                    else:
                        services[service][unit][metric_main][metric_sub] = datapoints
                else:
                    services[service][unit][metric_main] = {
                        metric_sub: datapoints
                    }
            else:
                services[service][unit] = {
                    metric_main: {
                        metric_sub: datapoints
                    }
                }
        else:
            services[service] = {
                unit: {
                    metric_main: {
                        metric_sub: datapoints
                    }
                }
            }
    return services


@view_config(route_name='api_actions', renderer='json')
def api_actions(request):
    api = API(request)
    return api.get_actions() or {}


@view_config(route_name='api_action', renderer='json')
def api_action(request):
    uuid = request.matchdict['action']

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound()

    action.get_graphs(request)
    action.get_tags(request)
    action.get_profile_data(request)
    return action


@view_config(route_name='api_action_cancel', request_method='POST')
def api_action_cancel(request):
    uuid = request.matchdict['action']
    api = API(request)
    api.cancel_action(uuid)
    return Response()


@view_config(route_name='unit', renderer='units/show.mako')
def unit(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    key = 'unit-{}-{}'.format(service, unit)

    r = Redis(request)
    result = r.get_profile_data(key)
    if not result:
        return HTTPNotFound()

    return {'unit': result}


@view_config(route_name='api_unit', renderer='json', request_method='GET')
def api_unit_get(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    action = request.params.get('action')
    key = 'unit-{}-{}'.format(service, unit)

    r = Redis(request)
    result = r.get_profile_data(key, action=action)
    return result or HTTPNotFound()


@view_config(route_name='api_unit', request_method='POST')
def api_unit_post(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    key = 'unit-{}-{}'.format(service, unit)
    data = request.json_body

    api = API(request)
    r = Redis(request)

    existing = r.get_profile_data(key) or []
    existing.append({
        "data": data,
        "timestamp": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "action": request.params.get('action'),
        "status": api.get_status(),
    })

    r.set_profile_data(key, existing)
    return HTTPFound()


@view_config(route_name='api_service', renderer='json', request_method='GET')
def api_service_get(request):
    service = request.matchdict['service']

    r = Redis(request)
    result = r.get_service_data(service)
    return result or HTTPNotFound()


@view_config(route_name='api_service', request_method='POST')
def api_service_post(request):
    service = request.matchdict['service']
    data = request.json_body

    r = Redis(request)
    r.set_service_data(service, data)
    return HTTPFound()


@view_config(route_name='api_comparison', renderer='json')
def api_comparison(request):
    id_ = request.matchdict['id']

    r = Redis(request)
    comparison = r.get_comparison(id_)
    if not comparison:
        return HTTPNotFound()

    return comparison


@view_config(route_name='api_comparison_graphs', request_method='POST',
             renderer='json')
def api_comparison_graphs_post(request):
    comparison_id = request.matchdict['id']
    datapoints = json.loads(request.params['datapoints'])
    label = request.params.get('label', '')

    r = Redis(request)
    graph_uuid = r.insert_comparison_graph(comparison_id, datapoints, label)

    return {
        'uuid': graph_uuid,
    }


@view_config(route_name='api_comparison_graph', request_method='DELETE')
def api_comparison_graph_delete(request):
    comparison_id = request.matchdict['id']
    graph_uuid = request.matchdict['graph']

    r = Redis(request)
    r.delete_comparison_graph(comparison_id, graph_uuid)

    return Response()
