import datetime
import json
import re

import requests

from pyramid.response import Response
from pyramid.view import view_config
from pyramid.httpexceptions import (
    HTTPBadRequest,
    HTTPFound,
    HTTPNotFound,
)

from .api import API
from .db import DB


@view_config(route_name='root', renderer='index.mako')
def root(request):
    """ Base view to load our single-page-app template """
    return {}


@view_config(route_name='api_root', renderer='json')
def api_root(request):
    api = API.from_request(request)
    db = DB.from_request(request)

    benchmarks = {}
    results = db.get_benchmarks()
    for name, actions in results.items():
        benchmarks[name] = {
            "actions": [a.to_dict() for a in actions],
            "result_keys": sorted(set(k for a in actions
                                      for k in a.results)),
        }
    return {
        'benchmarks': benchmarks,
        'settings': {
            'graphite_url': request.registry.settings['graphite.url'],
        },
        'action_specs': api.get_benchmark_action_specs(),
        'service_units': api.get_service_units(),
        'environment_count': db.get_environments().count(),
    }


@view_config(route_name='api_benchmarks', renderer='json')
def api_benchmarks(request):
    db = DB.from_request(request)
    return db.get_benchmarks() or {}


@view_config(route_name='actions', request_method='POST')
def action_create(request):
    d = request.params
    action = d['action']
    service = d['service']
    receivers = d.getall('receivers')
    tags = d.getall('tags')

    if receivers:
        api = API.from_request(request)
        action_spec = api.get_action_specs()[service][action]

        params = {}
        for prop in [k for k in d if k.startswith('prop-')]:
            prop_name = prop[5:]  # remove 'prop-' prefix
            prop_val = action_spec.properties[prop_name].to_python(d[prop])
            params[prop_name] = prop_val

        action = api.enqueue_action(action, receivers, params)
        if tags:
            r = DB.from_request(request)
            r.update_action_tags(action.uuid, tags)

    return HTTPFound(location=request.referer)


@view_config(route_name='action_graphs', request_method='POST',
             renderer='json')
def action_graphs_post(request):
    action_uuid = request.matchdict['action']
    datapoints = json.loads(request.params['datapoints'])
    label = request.params.get('label', '')

    r = DB.from_request(request)
    graph_uuid = r.insert_action_graph(action_uuid, datapoints, label)

    return {
        'uuid': graph_uuid,
    }


@view_config(route_name='action_graph', request_method='DELETE')
def action_graph_delete(request):
    action_uuid = request.matchdict['action']
    graph_uuid = request.matchdict['graph']

    r = DB.from_request(request)
    r.delete_action_graph(action_uuid, graph_uuid)

    return Response()


@view_config(route_name='action_tags', request_method='PUT',
             renderer='json')
def action_tags_put(request):
    action_uuid = request.matchdict['action']
    tags = json.loads(request.params['tags'])

    r = DB.from_request(request)
    r.update_action_tags(action_uuid, tags)

    return Response()


@view_config(route_name='action_svg', request_method='POST')
def action_svg(request):
    data = request.body
    r = requests.post('http://svg.juju.solutions', data)
    return Response(body=r.content, content_type='image/svg+xml')


@view_config(route_name='action_metrics')
def action_metrics(request):
    mime = {
        'json': 'application/json',
    }

    uuid = request.matchdict['action']
    format_ = request.params.get('format', 'json')
    if format_ not in mime:
        return HTTPBadRequest(
            'Unsupported metrics format "{}".'
            'Valid formats are: {}'.format(
                format_, ', '.join(mime.keys())))

    db = DB.from_request(request)
    action = db.get_action(uuid)
    if not action:
        return HTTPNotFound('No such action')

    return Response(
        json.dumps(format_metrics(action.metrics or [])),
        content_type=mime[format_])


def format_metrics(data):
    """Convert the metric data returned by Graphite into the structure that
    we actually want to use. Example of incoming/outgoing format:

    incoming = [{
        'target': 'unit-pts-0.tvansteenburgh-local-machine-1.battery-0.charge',
        'datapoints': [[y, x]]
    }]

    outgoing = {
      'pts': {
        '0': {
          'battery-0': {
            'charge': [{'x': x, 'y': y}]
          }
        }
      }
    }

    """
    services = {}
    for metric in data:
        target_parts = metric['target'].split('.')
        receiver = target_parts[0]
        if not re.match(r'unit-[^-]+-\d+', receiver):
            continue
        _, unit = receiver.rsplit('-', 1)
        _, service = _.split('-', 1)
        metric_main, metric_sub = target_parts[-2:]
        start_time = min(sorted([x for y, x in metric['datapoints']])) \
            if metric['datapoints'] else 0
        datapoints = [dict(x=x - start_time, y=y)
                      for y, x in metric['datapoints']]

        if service in services:
            if unit in services[service]:
                if metric_main in services[service][unit]:
                    if metric_sub in services[service][unit][metric_main]:
                        services[service][unit][metric_main][metric_sub].extend(datapoints)
                    else:
                        services[service][unit][metric_main][metric_sub] = datapoints
                else:
                    services[service][unit][metric_main] = {
                        metric_sub: datapoints
                    }
            else:
                services[service][unit] = {
                    metric_main: {
                        metric_sub: datapoints
                    }
                }
        else:
            services[service] = {
                unit: {
                    metric_main: {
                        metric_sub: datapoints
                    }
                }
            }
    return services


@view_config(route_name='api_actions', renderer='json')
def api_actions(request):
    db = DB.from_request(request)
    return [a.to_dict() for a in db.get_actions()]


@view_config(route_name='api_action', renderer='json')
def api_action(request):
    uuid = request.matchdict['action']

    db = DB.from_request(request)
    action = db.get_action(uuid)
    if not action:
        return HTTPNotFound()

    return action.to_dict()


@view_config(route_name='api_action_cancel', request_method='POST')
def api_action_cancel(request):
    uuid = request.matchdict['action']
    api = API.from_request(request)
    api.cancel_action(uuid)
    return Response()


@view_config(route_name='api_unit', renderer='json', request_method='GET')
def api_unit_get(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    action = request.params.get('action')
    key = 'unit-{}-{}'.format(service, unit)

    db = DB.from_request(request)
    result = db.get_profile_data(key, action=action)
    return result or HTTPNotFound()


@view_config(route_name='api_unit', request_method='POST')
def api_unit_post(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    key = 'unit-{}-{}'.format(service, unit)
    data = request.json_body

    api = API.from_request(request)
    db = DB.from_request(request)

    existing = db.get_profile_data(key) or []
    existing.append({
        "data": data,
        "timestamp": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "action": request.params.get('action'),
        "status": api.get_status(),
    })

    db.set_profile_data(key, existing)
    return HTTPFound()


@view_config(route_name='api_service', renderer='json', request_method='GET')
def api_service_get(request):
    service = request.matchdict['service']

    r = DB.from_request(request)
    result = r.get_service_data(service)
    return result or HTTPNotFound()


@view_config(route_name='api_service', request_method='POST')
def api_service_post(request):
    service = request.matchdict['service']
    data = request.json_body

    r = DB.from_request(request)
    r.set_service_data(service, data)
    return HTTPFound()


@view_config(route_name='api_comparison', renderer='json')
def api_comparison(request):
    id_ = request.matchdict['id']

    r = DB.from_request(request)
    comparison = r.get_comparison_data(id_)
    if not comparison:
        return HTTPNotFound()

    return comparison


@view_config(route_name='api_comparison_graphs', request_method='POST',
             renderer='json')
def api_comparison_graphs_post(request):
    comparison_id = request.matchdict['id']
    datapoints = json.loads(request.params['datapoints'])
    label = request.params.get('label', '')

    r = DB.from_request(request)
    graph_uuid = r.insert_comparison_graph(comparison_id, datapoints, label)

    return {
        'uuid': graph_uuid,
    }


@view_config(route_name='api_comparison_graph', request_method='DELETE')
def api_comparison_graph_delete(request):
    comparison_id = request.matchdict['id']
    graph_uuid = request.matchdict['graph']

    r = DB.from_request(request)
    r.delete_comparison_graph(comparison_id, graph_uuid)

    return Response()


@view_config(route_name='export')
def file_export(request):
    """Export database to json file.

    GET /export

    """
    db = DB.from_request(request)
    d = db.export_json()
    return Response(
        content_type='application/json',
        content_disposition='attachment; filename="export.json"',
        body=json.dumps(d))


@view_config(route_name='import', request_method='POST')
def file_import(request):
    """Import data from file upload.

    POST /import

    """
    f = request.POST['json_file'].file

    db = DB.from_request(request)
    db.import_json(json.load(f))
    return Response()


@view_config(route_name='api_export', renderer='json')
def api_export(request):
    """Export database to json.

    GET /api/export

    """
    db = DB.from_request(request)

    return db.export_json()


@view_config(route_name='api_import', request_method='POST')
def api_import(request):
    """Import data from json request body.

    POST /api/import

    """
    db = DB.from_request(request)
    db.import_json(request.json_body)
    return Response()
