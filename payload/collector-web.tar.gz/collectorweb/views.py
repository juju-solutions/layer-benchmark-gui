import datetime
import json

from pyramid.response import Response
from pyramid.view import view_config
from pyramid.httpexceptions import (
    HTTPBadRequest,
    HTTPFound,
    HTTPNotFound,
    HTTPServiceUnavailable,
)

from .api import API
from .db import Redis


@view_config(route_name='root', renderer='index.mako')
def root(request):
    api = API(request)
    benchmarks = api.get_benchmarks()
    return {'benchmarks': benchmarks}


@view_config(route_name='actions', request_method='POST')
def action_create(request):
    d = request.params
    action = d['action']
    service = d['service']
    receivers = d.getall('receivers')

    if receivers:
        api = API(request)
        action_spec = api.get_action_specs()[service][action]

        params = {}
        for prop in [k for k in d if k.startswith('prop-')]:
            prop_name = prop[5:]  # remove 'prop-' prefix
            prop_val = action_spec.properties[prop_name].to_python(d[prop])
            params[prop_name] = prop_val

        api.enqueue_action(action, receivers, params)

    return HTTPFound(location=request.route_url('actions'))


@view_config(route_name='actions', renderer='actions/index.mako')
def actions(request):
    api = API(request)
    actions = api.get_actions()
    action_specs = api.get_action_specs()
    service_units = api.get_service_units()

    return {
        'actions': actions,
        'action_specs': action_specs,
        'service_units': service_units,
    }


@view_config(route_name='action', renderer='actions/show.mako')
def action(request):
    uuid = request.matchdict['action']

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound()

    return {'action': action}


@view_config(route_name='action_metrics')
def action_metrics(request):
    mime = {
        'png': 'image/png',
        'json': 'application/json',
        'raw': 'application/octet-stream',
        'csv': 'text/csv',
        'svg': 'image/svg+xml',
    }

    uuid = request.matchdict['action']
    format_ = request.params.get('format', 'json')
    if format_ not in mime:
        return HTTPBadRequest(
            'Unsupported metrics format "{}".'
            'Valid formats are: {}'.format(
                format_, ', '.join(mime.keys())))

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound('No such action')

    r = action.get_metrics(request, format_=format_)
    if not r.status_code == 200:
        return HTTPServiceUnavailable(
            "Couldn't retrieve metrics from "
            "graphite server: {}".format(r.url))

    return Response(body=r.content, content_type=mime[format_])


@view_config(route_name='api_actions', renderer='json')
def api_actions(request):
    api = API(request)
    return api.get_actions() or {}


@view_config(route_name='api_action', renderer='json')
def api_action(request):
    uuid = request.matchdict['action']

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound()

    return action


@view_config(route_name='unit', renderer='units/show.mako')
def unit(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    key = 'unit-{}-{}'.format(service, unit)

    r = Redis(request)
    result = r.get_profile_data(key)
    if not result:
        return HTTPNotFound()

    return {'unit': result}


@view_config(route_name='api_unit', renderer='json', request_method='GET')
def api_unit_get(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    action = request.params.get('action')
    key = 'unit-{}-{}'.format(service, unit)

    r = Redis(request)
    result = r.get_profile_data(key, action=action)
    return result or HTTPNotFound()


@view_config(route_name='api_unit', renderer='json', request_method='POST')
def api_unit_post(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    key = 'unit-{}-{}'.format(service, unit)
    data = request.json_body

    api = API(request)
    r = Redis(request)

    existing = r.get_profile_data(key) or []
    existing.append({
        "data": data,
        "timestamp": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "action": request.params.get('action'),
        "status": api.get_status(),
        })

    r.set(key, json.dumps(existing))
