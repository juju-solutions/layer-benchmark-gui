import datetime
import difflib
import json

from pyramid.response import Response
from pyramid.view import view_config
from pyramid.httpexceptions import (
    HTTPBadRequest,
    HTTPFound,
    HTTPNotFound,
    HTTPServiceUnavailable,
)

from .api import API
from .db import Redis


@view_config(route_name='root', renderer='index.mako')
def root(request):
    api = API(request)
    benchmarks = api.get_benchmarks()
    return {'benchmarks': benchmarks}


@view_config(route_name='benchmarks', renderer='actions/index.mako')
def benchmarks(request):
    api = API(request)
    actions = api.get_benchmark_actions()
    action_specs = api.get_benchmark_action_specs()
    service_units = api.get_service_units()

    return {
        'actions': actions,
        'action_specs': action_specs,
        'service_units': service_units,
    }


@view_config(route_name='api_benchmarks', renderer='json')
def api_benchmarks(request):
    api = API(request)
    return api.get_benchmark_actions() or {}


@view_config(route_name='actions', request_method='POST')
def action_create(request):
    d = request.params
    action = d['action']
    service = d['service']
    receivers = d.getall('receivers')

    if receivers:
        api = API(request)
        action_spec = api.get_action_specs()[service][action]

        params = {}
        for prop in [k for k in d if k.startswith('prop-')]:
            prop_name = prop[5:]  # remove 'prop-' prefix
            prop_val = action_spec.properties[prop_name].to_python(d[prop])
            params[prop_name] = prop_val

        api.enqueue_action(action, receivers, params)

    return HTTPFound(location=request.referer)


@view_config(route_name='actions', renderer='actions/index.mako')
def actions(request):
    api = API(request)
    actions = api.get_actions()
    action_specs = api.get_action_specs()
    service_units = api.get_service_units()

    return {
        'actions': actions,
        'action_specs': action_specs,
        'service_units': service_units,
    }


@view_config(route_name='actions_compare', renderer='actions/compare.mako')
def actions_compare(request):
    from_uuid = request.params.get('from')
    to_uuid = request.params.get('to')

    api = API(request)
    from_ = api.get_action(from_uuid)
    to_ = api.get_action(to_uuid)
    if not from_ or not to_:
        return HTTPBadRequest(
            "'from' and 'to' params are required and must contain "
            "a valid action uuid")

    r = Redis(request)

    def get_profile(action):
        return r.get_profile_data(
            action.receiver, action=from_.uuid, start=action.start,
            stop=action.stop)

    def diff(from_, to_):
        def to_lines(d):
            return json.dumps(d, indent=2).split('\n')
        differ = difflib.HtmlDiff()
        return differ.make_table(to_lines(from_), to_lines(to_))

    from_profile = get_profile(from_)
    to_profile = get_profile(to_)

    return {
        'from_': from_,
        'to_': to_,
        'from_profile': from_profile,
        'to_profile': to_profile,
        'action_diff': diff(from_, to_),
        'profile_diff': (diff(from_profile, to_profile) if
                         from_profile and to_profile else None),
        'styles': difflib._styles,
    }


@view_config(route_name='action', renderer='actions/show.mako')
def action(request):
    uuid = request.matchdict['action']

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound()

    return {'action': action}


@view_config(route_name='action_metrics')
def action_metrics(request):
    mime = {
        'png': 'image/png',
        'json': 'application/json',
        'raw': 'application/octet-stream',
        'csv': 'text/csv',
        'svg': 'image/svg+xml',
    }

    uuid = request.matchdict['action']
    format_ = request.params.get('format', 'json')
    if format_ not in mime:
        return HTTPBadRequest(
            'Unsupported metrics format "{}".'
            'Valid formats are: {}'.format(
                format_, ', '.join(mime.keys())))

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound('No such action')

    r = action.get_metrics(request, format_=format_)
    if not r.status_code == 200:
        return HTTPServiceUnavailable(
            "Couldn't retrieve metrics from "
            "graphite server: {}".format(r.url))

    return Response(body=r.content, content_type=mime[format_])


@view_config(route_name='api_actions', renderer='json')
def api_actions(request):
    api = API(request)
    return api.get_actions() or {}


@view_config(route_name='api_action', renderer='json')
def api_action(request):
    uuid = request.matchdict['action']

    api = API(request)
    action = api.get_action(uuid)
    if not action:
        return HTTPNotFound()

    return action


@view_config(route_name='unit', renderer='units/show.mako')
def unit(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    key = 'unit-{}-{}'.format(service, unit)

    r = Redis(request)
    result = r.get_profile_data(key)
    if not result:
        return HTTPNotFound()

    return {'unit': result}


@view_config(route_name='api_unit', renderer='json', request_method='GET')
def api_unit_get(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    action = request.params.get('action')
    key = 'unit-{}-{}'.format(service, unit)

    r = Redis(request)
    result = r.get_profile_data(key, action=action)
    return result or HTTPNotFound()


@view_config(route_name='api_unit', request_method='POST')
def api_unit_post(request):
    service = request.matchdict['service']
    unit = request.matchdict['unit']
    key = 'unit-{}-{}'.format(service, unit)
    data = request.json_body

    api = API(request)
    r = Redis(request)

    existing = r.get_profile_data(key) or []
    existing.append({
        "data": data,
        "timestamp": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "action": request.params.get('action'),
        "status": api.get_status(),
        })

    r.set_profile_data(key, existing)
    return HTTPFound()


@view_config(route_name='api_service', renderer='json', request_method='GET')
def api_service_get(request):
    service = request.matchdict['service']

    r = Redis(request)
    result = r.get_service_data(service)
    return result or HTTPNotFound()


@view_config(route_name='api_service', request_method='POST')
def api_service_post(request):
    service = request.matchdict['service']
    data = request.json_body

    r = Redis(request)
    r.set_service_data(service, data)
    return HTTPFound()
