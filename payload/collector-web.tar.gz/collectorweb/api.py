import datetime

import jujuclient
import requests
import humanize

import dateutil.parser


class ActionEnvironment(jujuclient.Environment):
    def actions_available(self, service=None):
        args = {
            "Type": 'Action',
            "Request": 'ServicesCharmActions',
            "Params": {
                "Entities": []
            }
        }

        services = self.status().get('Services', {})
        service_names = [service] if service else services
        for name in service_names:
            args['Params']['Entities'].append(
                {
                    "Tag": 'service-' + name
                }
            )

        return self._rpc(args)

    def actions_list_all(self, service=None):
        args = {
            "Type": 'Action',
            "Request": 'ListAll',
            "Params": {
                "Entities": []
            }
        }

        services = self.status().get('Services', {})
        service_names = [service] if service else services
        for name in service_names:
            for unit in services[name]['Units'] or []:
                args['Params']['Entities'].append(
                    {
                        "Tag": "unit-%s" % unit.replace('/', '-'),
                    }
                )

        return self._rpc(args)

    def actions_enqueue(self, action, receivers, params=None):
        args = {
            "Type": "Action",
            "Request": "Enqueue",
            "Params": {
                "Actions": []
            }
        }

        for receiver in receivers:
            args['Params']['Actions'].append({
                "Receiver": receiver,
                "Name": action,
                "Parameters": params or {},
            })

        return self._rpc(args)


class API(object):
    def __init__(self, request):
        api_endpoint = request.registry.settings['juju.api.endpoint']
        api_user = request.registry.settings['juju.api.user']
        api_secret = request.registry.settings['juju.api.secret']

        try:
            env = ActionEnvironment(api_endpoint)
            env.login(api_secret, user=api_user)
        except jujuclient.EnvError as e:
            # _exit("Couldn't connect to Juju API server: {}".format(
            #    e.message))
            raise e

        self.env = env

    def get_status(self):
        return self.env.status()

    def get_actions(self, service=None):
        return self.env.actions_list_all(service)

    def get_action(self, uuid):
        results = self.get_actions()
        if not results:
            return None

        uuid = 'action-' + uuid
        for receiver_actions in results.get('actions', []):
            for action in receiver_actions.get('actions', {}):
                if uuid == action['action']['tag']:
                    return Action(action)

    def get_benchmarks(self):
        benchmarks = {}

        actions = self.get_actions()
        if not actions:
            return benchmarks

        for receiver_actions in actions.get('actions', []):
            for action in receiver_actions.get('actions', {}):
                a = Action(action)
                benchmarks.setdefault(a.benchmark_name, []).append(a)
        return benchmarks

    def get_service_units(self):
        results = {}

        services = self.env.status().get('Services', {})
        for svc_name, svc_data in services.items():
            results[svc_name] = svc_data['Units']
        return results

    def get_action_specs(self):
        results = self.env.actions_available()
        return _parse_action_specs(results)

    def enqueue_action(self, action, receivers, params):
        return self.env.actions_enqueue(action, receivers, params)


def _parse_action_specs(api_results):
    results = {}

    r = api_results['results']
    for service in r:
        servicetag = service['servicetag']
        service_name = servicetag[8:]  # remove 'service-' prefix
        specs = {}
        if service['actions']['ActionSpecs']:
            for spec_name, spec_def in service['actions']['ActionSpecs'].items():
                specs[spec_name] = ActionSpec(spec_def)
        results[service_name] = specs
    return results


def _parse_action_properties(action_properties_dict):
    results = {}

    d = action_properties_dict
    for prop_name, prop_def in d.items():
        results[prop_name] = ActionProperty(prop_name, prop_def)
    return results


def _get_graph_url(request, action, format_=None, target=None):
    graphite_url = request.registry.settings['graphite.url']
    graphite_format = format_ or request.registry.settings['graphite.format']
    target = target or '{}.*.*.*'.format(action.receiver)

    def _format_date(d):
        if not d:
            return d

        return d.astimezone(dateutil.tz.tzutc()).strftime('%H:%M_%Y%m%d')

    start = _format_date(action.start) or '-5min'
    stop = _format_date(action.stop)

    url = '{}/render?height=340&width=420&target={}&format={}'.format(
        graphite_url, target, graphite_format)

    if start:
        url += '&from={}'.format(start)
    if stop:
        url += '&until={}'.format(stop)

    return url


class Graph(object):
    def __init__(self, name, url):
        self.name = name
        self.url = url


class Action(dict):
    def get_profile_data(self, request):
        from .db import Redis

        return Redis(request).get_profile_data(
            self.receiver, self.uuid, self.start, self.stop)

    def get_graphs(self, request):
        self.graphs = {}

        url = _get_graph_url(request, self, format_='json', target='*.*.*.*')
        r = requests.get(url)
        if not r.status_code == 200:
            return self.graphs

        targets, seen = [d['target'] for d in r.json()], []
        for t in targets:
            parts = t.split('.')
            unit, name = parts[0], parts[2]
            if (unit, name) in seen or not unit.startswith('unit'):
                continue
            seen.append((unit, name))
            wildcards = len(parts) - 3
            new_target = '.'.join(parts[:3] + ['*' * wildcards])
            self.graphs.setdefault(unit, []).append(
                Graph(name, _get_graph_url(
                    request, self, target=new_target)))

        return self.graphs

    def get_metrics(self, request, format_='json'):
        url = _get_graph_url(request, self, format_=format_)
        return requests.get(url)

    @property
    def benchmark_name(self):
        return '{}:{}'.format(self.service, self.name)

    @property
    def service(self):
        _, service, unit = self['action']['receiver'].split('-')
        return service

    @property
    def name(self):
        return self['action']['name']

    @property
    def status(self):
        return self['status']

    @property
    def start(self):
        return self._date('started')

    @property
    def stop(self):
        if not self.start:
            return None

        if not self._date('completed') or self._date('completed') < self.start:
            return None

        return self._date('completed')

    def _date(self, key):
        try:
            start = self[key]
            return dateutil.parser.parse(start)
        except KeyError:
            return None

    @property
    def duration(self):
        start, stop = self.start, self.stop
        if start and stop:
            return stop - start
        return None

    @property
    def human_start(self):
        if not self.start:
            return None

        t = datetime.datetime.utcnow().replace(tzinfo=dateutil.tz.tzutc())
        return humanize.naturaltime(t - self.start)

    @property
    def human_stop(self):
        if not self.stop:
            return None

        t = datetime.datetime.utcnow().replace(tzinfo=dateutil.tz.tzutc())
        return humanize.naturaltime(t - self.stop)

    @property
    def tag(self):
        return self['action']['tag']

    @property
    def uuid(self):
        return self.tag[len('action-'):]

    @property
    def receiver(self):
        return self['action']['receiver']

    @property
    def parameters(self):
        return self['action'].get('parameters', {})

    @property
    def unit(self):
        return self.receiver[len('unit-'):].replace('-', '/')

    @property
    def results(self):
        return self.get('output', {}).get('results', {})


class ActionSpec(object):
    def __init__(self, data_dict):
        self.data = d = data_dict
        params = d['Params']
        self.title = params['title']
        self.description = params['description']
        self.properties = _parse_action_properties(params['properties'])


class ActionProperty(object):
    types = {
        'string': str,
        'integer': int,
    }

    def __init__(self, name, data_dict):
        self.data = d = data_dict
        self.name = name
        self.description = d.get('description', '')
        self.default = d.get('default', '')
        self.type = d['type']

    def to_python(self, value):
        f = self.types.get(self.type)
        return f(value) if f else value
