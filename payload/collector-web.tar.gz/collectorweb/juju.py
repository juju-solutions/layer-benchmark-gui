"""
juju cli available (running locally)
- juju version
- juju switch
- get uuid/password

juju cli not available (running deployed)
- get version/uuid from env vars
- get password from config

"""
import os
import subprocess

import yaml


def juju(*args):
    return subprocess.check_output(['juju'] + list(args))


def get_api_info():
    version = juju('version').strip()
    model = juju('switch').strip()
    if version.startswith('1'):
        juju_home = os.getenv("JUJU_HOME", "~/.juju")
        env = os.path.expanduser(
            os.path.join(
                juju_home,
                "environments/{}.jenv".format(model)))
        if not os.path.isfile(env):
            raise Exception("Unable to locate: {}".format(env))
        env_yaml = yaml.load(open(env))
        uuid = env_yaml['environ-uuid']
        server = env_yaml['state-servers'][0]
        password = env_yaml['password']
        user = env_yaml['user']
        url = os.path.join('wss://', server, 'environment', uuid, 'api')
    else:
        controller, model = model.split(':')
        xdg_home = os.getenv("XDG_DATA_HOME", "~/.local/share")
        juju_home = os.path.join(xdg_home, 'juju')
        controllers = os.path.expanduser(
            os.path.join(
                juju_home,
                "controllers.yaml"))
        accounts = os.path.expanduser(
            os.path.join(
                juju_home,
                "accounts.yaml"))
        models = os.path.expanduser(
            os.path.join(
                juju_home,
                "models.yaml"))
        if (not os.path.isfile(controllers) or
                not os.path.isfile(accounts) or
                not os.path.isfile(models)):
            raise Exception("Unable to locate: {}".format(env))

        controllers = yaml.load(open(controllers))
        accounts = yaml.load(open(accounts))
        models = yaml.load(open(models))
        user = models['controllers'][controller]['accounts'].keys()[0]
        uuid = models['controllers'][controller]['accounts'][user]['models'][model]['uuid']
        server = controllers['controllers'][controller]['api-endpoints'][0]
        password = accounts['controllers'][controller]['accounts'][user]['password']
        url = os.path.join('wss://', server, 'model', uuid, 'api')

    if not user.startswith('user-'):
        user = 'user-' + user
    return url, password, user
