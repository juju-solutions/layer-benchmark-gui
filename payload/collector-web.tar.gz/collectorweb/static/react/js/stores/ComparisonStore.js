var AppDispatcher = require('../dispatcher/AppDispatcher');
var EventEmitter = require('events').EventEmitter;
var ComparisonConstants = require('../constants/ComparisonConstants');
var assign = require('object-assign');

var CHANGE_EVENT = 'change';

var _data = {};


/**
 * Fetch a comparison.
 */
function fetchComparison(id) {
  var url = '/api/comparisons/' + id;
  $.ajax({
    url: url,
    dataType: 'json',
    success: function(data) {
      _data[id] = data;
      console.log('comparison fetched', id);
      ComparisonStore.emitChange();
    },
    error: function(xhr, status, err) {
      console.error(url, status, err.toString());
    }
  });
}

/**
 * Delete graph for a comparison.
 */
function deleteGraph(comparison_id, graph_uuid) {
  delete _data[comparison_id].graphs[graph_uuid];
  ComparisonStore.emitChange();

  var url = `/api/comparisons/${comparison_id}/graph/${graph_uuid}`;
  $.ajax({
    url: url,
    type: 'DELETE',
    success: function(data) {
    },
    error: function(xhr, status, err) {
    }
  });
}

var ComparisonStore = assign({}, EventEmitter.prototype, {

  /**
   * Get one comparison by id.
   * @param {string} id
   * @return {object}
   */
  get: function(id) {
    var comparison = _data[id];
    return comparison;
  },

  /**
   * Get the entire collection of comparisons.
   * @return {object}
   */
  getAll: function() {
    return _data;
  },

  emitChange: function() {
    this.emit(CHANGE_EVENT);
  },

  /**
   * @param {function} callback
   */
  addChangeListener: function(callback) {
    this.on(CHANGE_EVENT, callback);
  },

  /**
   * @param {function} callback
   */
  removeChangeListener: function(callback) {
    this.removeListener(CHANGE_EVENT, callback);
  }
});

// Register callback to handle all updates
AppDispatcher.register(function(action) {

  switch(action.actionType) {

    case ComparisonConstants.COMPARISON_REFRESH:
      fetchComparison(action.comparison_id);
      break;

    case ComparisonConstants.COMPARISON_DELETE_GRAPH:
      deleteGraph(action.comparison_id, action.graph_uuid);
      break;

    default:
      // no op
  }
});

module.exports = ComparisonStore;
