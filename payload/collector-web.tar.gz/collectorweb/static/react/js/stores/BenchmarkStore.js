var AppDispatcher = require('../dispatcher/AppDispatcher');
var EventEmitter = require('events').EventEmitter;
var BenchmarkConstants = require('../constants/BenchmarkConstants');
var assign = require('object-assign');

var CHANGE_EVENT = 'change';

var _data = {};
var _index = {};
var _graphs = {};
var _metrics = {};
var _isLaunchPending = false;


/**
 * Launch a new benchmark rum
 */
function launchBenchmark(data) {
  $.post('/actions', data);
  _isLaunchPending = true;
}

/**
 * Refetch all benchmark data.
 */
function fetchAll() {
  var url = '/api';
  $.ajax({
    url: url,
    dataType: 'json',
    success: function(data) {
      _isLaunchPending = false;
      _data = data;
      refreshIndex();
      console.log('benchmarks updated');
      BenchmarkStore.emitChange();
    },
    error: function(xhr, status, err) {
      console.error(url, status, err.toString());
    }
  });
}

/**
 * Create an index into _data, by action uuid.
 */
function refreshIndex() {
  var benchmarks = _data.benchmarks;
  var benchmark, action;

  if (!benchmarks) {
    return;
  }

  _index = {};

  for (var b in benchmarks) {
    benchmark = benchmarks[b];
    if (!benchmark.actions) {
      continue;
    }
    for (var i in benchmark.actions) {
      action = benchmark.actions[i];
      _index[action.uuid] = action;
    }
  }
}

/**
 * Fetch graph data for an action.
 */
function fetchGraphs(uuid) {
  var url = '/api/actions/' + uuid;
  $.ajax({
    url: url,
    dataType: 'json',
    success: function(data) {
      _graphs[uuid] = data.graphs;
      console.log('graphs updated for ' + uuid);
      BenchmarkStore.emitChange();
    },
    error: function(xhr, status, err) {
      console.error(url, status, err.toString());
    }
  });
}

/**
 * Delete graph for an action.
 */
function deleteGraph(action_uuid, graph_uuid) {
  delete _graphs[action_uuid][graph_uuid];
  BenchmarkStore.emitChange();

  var url = `/actions/${action_uuid}/graph/${graph_uuid}`;
  $.ajax({
    url: url,
    type: 'DELETE',
    success: function(data) {
    },
    error: function(xhr, status, err) {
    }
  });
}

/**
 * Cancel a benchmark.
 */
function cancelBenchmark(uuid) {
  _index[uuid].status = 'canceling';
  BenchmarkStore.emitChange();

  var url = `/api/actions/${uuid}/cancel`;
  $.ajax({
    url: url,
    type: 'POST',
    success: function(data) {
    },
    error: function(xhr, status, err) {
    }
  });
}

/**
 * Update tags for an action.
 */
function updateBenchmarkTags(action_uuid, tags) {
  _index[action_uuid].tags = tags;
  BenchmarkStore.emitChange();

  $.ajax({
    url: `/actions/${action_uuid}/tags`,
    data: {tags: JSON.stringify(tags)},
    type: 'PUT',
    success: function(data) {
    },
    error: function(xhr, status, err) {
    }
  });
}

/**
 * Fetch metric data for an action.
 */
function fetchMetrics(uuid) {
  var url = '/actions/' + uuid + '/metrics';
  $.ajax({
    url: url,
    dataType: 'json',
    success: function(data) {
      _metrics[uuid] = data;
      console.log('metrics updated for ' + uuid);
      BenchmarkStore.emitChange();
    },
    error: function(xhr, status, err) {
      console.error(url, status, err.toString());
    }
  });
}

var BenchmarkStore = assign({}, EventEmitter.prototype, {

  /**
   * Get one benchmark by uuid.
   * @param {string} uuid
   * @return {object}
   */
  get: function(uuid) {
    var action = _index[uuid];
    action['graphs'] = _graphs[uuid];
    action['metrics'] = _metrics[uuid];
    return action;
  },

  /**
   * Get the entire collection of BENCHMARKs.
   * @return {object}
   */
  getAll: function() {
    return _data;
  },

  getIndex: function() {
    return _index;
  },

  getSettings: function() {
    return _data.settings;
  },

  getEnvironmentCount: function() {
    return _data.environment_count;
  },

  isLaunchPending: function() {
    return _isLaunchPending;
  },

  emitChange: function() {
    this.emit(CHANGE_EVENT);
  },

  /**
   * @param {function} callback
   */
  addChangeListener: function(callback) {
    this.on(CHANGE_EVENT, callback);
  },

  /**
   * @param {function} callback
   */
  removeChangeListener: function(callback) {
    this.removeListener(CHANGE_EVENT, callback);
  }
});

// Register callback to handle all updates
AppDispatcher.register(function(action) {

  switch(action.actionType) {

    case BenchmarkConstants.BENCHMARK_REFRESH_ALL:
      fetchAll();
      break;

    case BenchmarkConstants.BENCHMARK_REFRESH_GRAPHS:
      fetchGraphs(action.uuid);
      break;

    case BenchmarkConstants.BENCHMARK_DELETE_GRAPH:
      deleteGraph(action.action_uuid, action.graph_uuid);
      break;

    case BenchmarkConstants.BENCHMARK_REFRESH_METRICS:
      fetchMetrics(action.uuid);
      break;

    case BenchmarkConstants.BENCHMARK_LAUNCH:
      launchBenchmark(action.data);
      break;

    case BenchmarkConstants.BENCHMARK_CANCEL:
      cancelBenchmark(action.uuid);
      break;

    case BenchmarkConstants.BENCHMARK_UPDATE_TAGS:
      updateBenchmarkTags(action.uuid, action.tags);
      break;

    default:
      // no op
  }
});

module.exports = BenchmarkStore;
