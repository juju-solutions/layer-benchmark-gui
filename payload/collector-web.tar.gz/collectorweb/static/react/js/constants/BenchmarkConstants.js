var keyMirror = require('keymirror');

module.exports = keyMirror({
  BENCHMARK_REFRESH_ALL: null,
  BENCHMARK_REFRESH_GRAPHS: null,
  BENCHMARK_DELETE_GRAPH: null,
  BENCHMARK_REFRESH_METRICS: null,
  BENCHMARK_LAUNCH: null,
  BENCHMARK_CANCEL: null,
  BENCHMARK_UPDATE_TAGS: null
});
