var React = require('react');

var TableRow = React.createClass({
  render: function() {
    return (
      <tr>
        {this.props.cols.map(function(val) {
          return (
            <td>{val}</td>
          );
        })}
      </tr>
    );
  }
});

module.exports = TableRow;
