var React = require('react');
var Router = require('react-router');
var BS = require('react-bootstrap');
var _ = require('underscore');
var TagsInput = require('react-tagsinput');

var BenchmarkTable = require('./BenchmarkTable.react');
var BenchmarkActions = require('../actions/BenchmarkActions');
var BenchmarkStore = require('../stores/BenchmarkStore');
var Header = require('./Header.react');

var FilterBar = React.createClass({
  propTypes: {
    actions: React.PropTypes.arrayOf(React.PropTypes.object).isRequired,
    onChange: React.PropTypes.func.isRequired
  },

  getInitialState: function() {
    return {
      filters: [],
    }
  },

  _handleAdd: function(filter) {
    this.state.filters.push(filter);
    this.setState({
      filters: this.state.filters
    });
    this.props.onChange(this.state.filters);
  },

  _handleRemove: function(filter) {
    var filters = _.filter(this.state.filters, _.negate(_.matcher(filter)));
    this.setState({
      filters: filters
    });
    this.props.onChange(filters);
  },

  render: function() {
    var self = this;
    var filters = [{
      title: 'Status',
      key: 'status'
    }, {
      title: 'Type',
      key: 'name'
    }, {
      title: 'Service',
      key: 'service'
    }, {
      title: 'Unit',
      key: 'unit'
    }, {
      title: 'Tags',
      key: 'tags',
      type: TagsFilter
    }];
    return (
      <BS.Panel header={<h3>Filter</h3>} className="filter-bar">
      {filters.map(function(filter) {
        return React.createElement(filter.type || PropertyFilter, {
          title: filter.title,
          name: filter.key,
          actions: self.props.actions,
          onAdd: self._handleAdd,
          onRemove: self._handleRemove,
          selected: _.contains(_.pluck(self.state.filters, 'name'), filter.key),
          key: filter.key
        });
      })}
      </BS.Panel>
    );
  }
});

var FilterMixin = {
  propTypes: {
    title: React.PropTypes.string,
    name: React.PropTypes.string,
    actions: React.PropTypes.arrayOf(React.PropTypes.object).isRequired,
    onAdd: React.PropTypes.func.isRequired,
    onRemove: React.PropTypes.func.isRequired,
    selected: React.PropTypes.bool
  },

  _handleClick: function(value, selected) {
    var f = selected ?
      this.props.onAdd:
      this.props.onRemove;
    f({
      name: this.props.name,
      value: value,
      matcher: this._matcher
    });
  },

  render: function() {
    var items = this._getItems();

    if (!this._shouldBeVisible(items)) {
      return null;
    }

    return (
      <div>
        <h4>{this.props.title}</h4>
        {_.keys(items).sort().map(function(value) {
          return (
            <FilterItem
              name={value}
              count={items[value]}
              onClick={this._handleClick}
              key={value}
            />
          );
        }.bind(this))}
      </div>
    );
  }
};

var TagsFilter = React.createClass({
  mixins: [FilterMixin],

  _getItems: function() {
    var tags = _.flatten(_.pluck(this.props.actions, 'tags'));
    return _.countBy(tags, function(tag) {
      return tag;
    });
  },

  _shouldBeVisible: function(items) {
    return _.keys(items).length > 0 || this.props.selected;
  },

  _matcher: function(filter, action) {
    return action.tags.indexOf(filter.value) > -1;
  }
});

var PropertyFilter = React.createClass({
  mixins: [FilterMixin],

  _getItems: function() {
    return _.countBy(this.props.actions, function(action) {
      return action[this.props.name];
    }.bind(this));
  },

  _shouldBeVisible: function(items) {
    return _.keys(items).length > 1 || this.props.selected;
  },

  _matcher: function(filter, action) {
    return action[filter.name] == filter.value;
  }
});

var FilterItem = React.createClass({
  propTypes: {
    name: React.PropTypes.string,
    count: React.PropTypes.number
  },

  getInitialState: function() {
    return {
      selected: false
    }
  },

  _handleClick: function(value) {
    var selected = !this.state.selected;
    this.setState({
      selected: selected
    });
    this.props.onClick(value, selected);
  },

  render: function() {
    var handler = this._handleClick.bind(this, this.props.name);
    return (
      <div>
        {this.state.selected &&
          <a onClick={handler} className="pull-right">X</a>}
        <a onClick={handler}>{this.props.name} ({this.props.count})</a>
      </div>
    );
  }
});

var BenchmarkDashboard = React.createClass({
  contextTypes: {
    router: React.PropTypes.func
  },

  propTypes: {
    actions: React.PropTypes.arrayOf(React.PropTypes.object).isRequired,
    action_specs: React.PropTypes.object.isRequired,
    service_units: React.PropTypes.object.isRequired
  },

  getInitialState: function() {
    return {
      isLaunchFormVisible: false,
      isImportFormVisible: false,
      selectedBenchmarks: [],
      filters: [],
      filteredActions: this.props.actions
    };
  },

  componentWillMount: function() {
    this._applyFilters(this.state.filters, this.props.actions);
  },

  componentWillReceiveProps: function(nextProps) {
    this._applyFilters(this.state.filters, nextProps.actions);
  },

  _applyFilters: function(filters, actions) {
    var i = 0;
    var filteredActions;

    while (i < filters.length) {
      filteredActions = _.filter(actions, function(action) {
        return filters[i].matcher(filters[i], action);
      });
      if (filteredActions.length === 0) {
        filters.splice(i, 1);
      }
      else {
        actions = filteredActions;
        i++;
      }
    }

    this.setState({
      filters: filters,
      filteredActions: actions
    });
  },

  handleFilterChanged: function(filters) {
    this._applyFilters(filters, this.props.actions);
  },

  handleExport: function() {
    window.open('/export');
  },

  handleImport: function() {
    this.setState({
      isImportFormVisible: true,
      isLaunchFormVisible: false
    });
  },

  hideImportForm: function() {
    this.setState({
      isImportFormVisible: false
    });
  },

  render: function() {
    var actions = this.state.filteredActions;
    return (
      <div>
        <Header>
          <ActionButton
            onLaunch={this.showLaunchForm}
            onCompare={this.handleCompare}
            onCancelBenchmark={this.handleCancelBenchmark}
            selectedBenchmarks={this.state.selectedBenchmarks}
            onExport={this.handleExport}
            onImport={this.handleImport}
          />
          {this.state.selectedBenchmarks.length > 0 &&
          <div className="pull-right selected-count">
            {this.state.selectedBenchmarks.length} selected
          </div>
          }
          <h1>Benchmarks</h1>
          {this.state.isLaunchFormVisible &&
            <LaunchForm
              actionSpecs={this.props.action_specs}
              serviceUnits={this.props.service_units}
              onCancel={this.hideLaunchForm}
              onSubmit={this.hideLaunchForm}
            />
          }
          {this.state.isImportFormVisible &&
            <ImportForm
              onCancel={this.hideImportForm}
              onSubmit={this.hideImportForm}
            />
          }
        </Header>
        <div className="container">
          <div className="row">
            <div className="col-md-3">
              <FilterBar actions={actions} onChange={this.handleFilterChanged} />
            </div>
            <div className="col-md-9">
              <BenchmarkTable
                data={actions}
                onBenchmarkSelected={this.handleBenchmarkSelected}
                onBenchmarkDeselected={this.handleBenchmarkDeselected}
                selectedBenchmarks={this.state.selectedBenchmarks}
                launchPending={BenchmarkStore.isLaunchPending()}
                environmentCount={BenchmarkStore.getEnvironmentCount()}
              />
            </div>
          </div>
        </div>
      </div>
    );
  },

  handleBenchmarkSelected: function(uuid) {
    var selected = this.state.selectedBenchmarks;

    if (selected.length === 2) {
      selected.pop();
    }
    selected.push(uuid);
    this.setState({
      selectedBenchmarks: selected
    });
  },

  handleBenchmarkDeselected: function(uuid) {
    this.setState({
      selectedBenchmarks: _.without(this.state.selectedBenchmarks, uuid)
    });
  },

  hideLaunchForm: function() {
    this.setState({
      isLaunchFormVisible: false
    });
  },

  showLaunchForm: function() {
    this.setState({
      isLaunchFormVisible: true,
      isImportFormVisible: false
    });
  },

  handleCancelBenchmark: function(uuid) {
    BenchmarkActions.cancelBenchmark(uuid);
  },

  handleCompare: function(event) {
    event.stopPropagation();
    event.preventDefault();
    this.context.router.transitionTo("compare", null, {
      from: this.state.selectedBenchmarks[0],
      to: this.state.selectedBenchmarks[1]
    });
  }

});

var ActionButton = React.createClass({
  render: function() {
    if (this.props.selectedBenchmarks.length === 2) {
      return (
        <BS.DropdownButton
          bsStyle="primary"
          title="Take Action"
          className="pull-right btn-launch"
        >
          <BS.MenuItem
            onClick={this.props.onCompare}
          >Compare Selected</BS.MenuItem>
          <BS.MenuItem divider />
          <BS.MenuItem
            onClick={this.props.onLaunch}
          >Launch Benchmark</BS.MenuItem>
        </BS.DropdownButton>
      );
    }
    else if (this.props.selectedBenchmarks.length === 1 &&
             _.contains(['pending', 'running'],
                        BenchmarkStore.get(
                          this.props.selectedBenchmarks[0]).status)) {
      return (
        <BS.DropdownButton
          bsStyle="primary"
          title="Take Action"
          className="pull-right btn-launch"
        >
          <BS.MenuItem
            onClick={this.props.onCancelBenchmark.bind(this, this.props.selectedBenchmarks[0])}
          >Cancel Benchmark</BS.MenuItem>
          <BS.MenuItem divider />
          <BS.MenuItem
            onClick={this.props.onLaunch}
          >Launch Benchmark</BS.MenuItem>
        </BS.DropdownButton>
      );
    }
    else {
      return (
        <BS.DropdownButton
          bsStyle="primary"
          title="Take Action"
          className="pull-right btn-launch"
        >
          <BS.MenuItem
            onClick={this.props.onLaunch}
          >Launch Benchmark</BS.MenuItem>
          <BS.MenuItem
            onClick={this.props.onExport}
          >Export Data</BS.MenuItem>
          <BS.MenuItem
            onClick={this.props.onImport}
          >Import Data</BS.MenuItem>
        </BS.DropdownButton>
      );
    }
  }
});

var LaunchForm = React.createClass({
  getInitialState: function() {
    for (var service in this.props.actionSpecs) {
      for (var spec_name in this.props.actionSpecs[service]) {
        return {
          selectedService: service,
          selectedSpec: this.props.actionSpecs[service][spec_name]
        };
      }
    }
    return {
      selectedService: null,
      selectedSpec: null
    };
  },

  render: function() {
    return (
      <div className="launch-form">
        <BenchmarkSelector
          actionSpecs={this.props.actionSpecs}
          onSelect={this.onBenchmarkSelected}
          selectedService={this.state.selectedService}
          selectedSpec={this.state.selectedSpec}
        />
        <BenchmarkForm
          service={this.state.selectedService}
          spec={this.state.selectedSpec}
          serviceUnits={this.props.serviceUnits[this.state.selectedService]}
          onCancel={this.props.onCancel}
          onSubmit={this.props.onSubmit}
        />
      </div>
    );
  },

  onBenchmarkSelected: function(service, spec) {
    this.setState({
      'selectedService': service,
      'selectedSpec': spec
    });
  }
});

var BenchmarkSelector = React.createClass({
  propTypes: {
    actionSpecs: React.PropTypes.objectOf(React.PropTypes.object).isRequired,
    onSelect: React.PropTypes.func.isRequired,
    selectedService: React.PropTypes.string,
    selectedSpec: React.PropTypes.object
  },

  render: function() {
    var choices = [];

    for (var service in this.props.actionSpecs) {
      for (var spec_name in this.props.actionSpecs[service]) {
        choices.push(
          <BS.NavItem
            onClick={this.onSelection.bind(this, service, this.props.actionSpecs[service][spec_name])}
            className={(service === this.props.selectedService &&
                        spec_name === this.props.selectedSpec.name) ? 'active' : ''}
          >{service}:{spec_name}</BS.NavItem>
        );
      }
    }

    return (
      <BS.Nav bsStyle="pills" activeKey={0}>
        {choices}
      </BS.Nav>
    );
  },

  onSelection: function(service, spec) {
    this.props.onSelect(service, spec);
  }
});

var ImportForm = React.createClass({
  propTypes: {
    onSubmit: React.PropTypes.func.isRequired,
    onCancel: React.PropTypes.func.isRequired,
  },

  onSubmit: function() {
    var files = this.refs.file.getDOMNode().files;

    if (files.length === 0) {
      alert("Choose a file to import");
      return;
    }

    var data = new FormData();
    data.append('json_file', files[0], files[0].name);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/import', true);
    xhr.onload = function () {
      if (xhr.status === 200) {
        BenchmarkActions.refreshAll();
        alert("Import succeeded");
      } else {
        alert("Import failed");
      }
    };
    xhr.send(data);

    this.props.onSubmit();
  },

  render: function() {
    return (
      <div className="launch-form">
        <form ref="form" className='form-horizontal launch' >
          <div>
            <div className="row">
              <label className="col-sm-2">Import JSON File</label>
              <div className="col-sm-10">
                <input ref="file" type="file" name="json_file" />
              </div>
            </div>
          </div>
          <div className="divide"></div>
          <BS.ButtonToolbar>
            <BS.Button onClick={this.onSubmit} bsStyle="primary">Import</BS.Button>
            <BS.Button onClick={this.props.onCancel}>Cancel</BS.Button>
          </BS.ButtonToolbar>
        </form>
      </div>
    );
  }
});

var BenchmarkForm = React.createClass({
  propTypes: {
    service: React.PropTypes.string,
    spec: React.PropTypes.object,
    serviceUnits: React.PropTypes.objectOf(React.PropTypes.object).isRequired,
    onSubmit: React.PropTypes.func.isRequired,
    onCancel: React.PropTypes.func.isRequired,
  },

  render: function() {
    var props = this.props;
    var prop;
    var key = `${this.props.service}:${this.props.spec.name}`;

    return (
      <form ref="form" className='form-horizontal launch' >
        <div>
          <div className="row">
            <label className="col-sm-2">Description</label>
            <div className="col-sm-10">
              <strong>{props.spec.description}</strong>
            </div>
          </div>
        </div>
        <div>
          <div className="row">
            <label className="col-sm-2">Units</label>
            <div className="col-sm-10">
              {Object.keys(props.serviceUnits).map(function(unit) {
                return (
                  <label key={`${key}:${unit}`}>
                    <input
                      type="checkbox"
                      label={unit}
                      value={'unit-' + unit.replace('/', '-')}
                      name="receivers"
                    />
                    <span>{unit}</span>
                  </label>
                );
              })}
            </div>
          </div>
        </div>
        <div className="parameters">
          <div className="row">
            <label className="col-sm-2">Tags</label>
            <div className="col-sm-10">
              <TagsInput
                ref='tags'
              />
            </div>
          </div>
        </div>
        {Object.keys(props.spec.properties).length > 0 ?
        <div className="parameters">
          <div className="row">
            <label className="col-sm-2">Parameters</label>
            <div className="col-sm-10">
              <div className="row">
              {Object.keys(props.spec.properties).map(function(propName) {
                prop = props.spec.properties[propName];
                return prop.type === 'boolean' ?
                  <div className="checkbox col-sm-6" key={`${key}:${prop.name}`}>
                    <label>
                      <input type="checkbox"
                        defaultValue={prop.default ? 1 : 0}
                        defaultChecked={prop.default}
                        name={'prop-' + prop.name}
                      /> {prop.name}
                    </label>
                    <p className="help-block">{prop.description}</p>
                  </div>
                  :
                  <div className="col-sm-6" key={`${key}:${prop.name}`}>
                    <label>{prop.name}</label>
                    <input type="text" defaultValue={prop.default} name={'prop-' + prop.name}/>
                    <p className="help-block">{prop.description}</p>
                  </div>
                ;
              })}
              </div>
            </div>
          </div>
        </div> : null
        }
        <input type="hidden" name="service" value={props.service}/>
        <input type="hidden" name="action" value={props.spec.name}/>
        <div className="divide"></div>
        <BS.ButtonToolbar>
          <BS.Button onClick={this.onSubmit} bsStyle="primary">Launch</BS.Button>
          <BS.Button onClick={props.onCancel}>Cancel</BS.Button>
        </BS.ButtonToolbar>
      </form>
    );
  },

  onSubmit: function() {
    var tags = this.refs.tags.getTags().map(function(tag) {
      return `tags=${tag}`;
    }).join('&');
    var formData = $(this.refs.form.getDOMNode()).serialize();

    if (tags) {
      formData += `&${tags}`;
    }

    BenchmarkActions.launchBenchmark(formData);
    this.props.onSubmit();
  }
});

module.exports = BenchmarkDashboard;
