var React = require('react');

var Header = React.createClass({
  render: function() {
    return (
      <div className="header">
        <div className="container">
          {this.props.children}
        </div>
      </div>
    );
  }
});

module.exports = Header;
