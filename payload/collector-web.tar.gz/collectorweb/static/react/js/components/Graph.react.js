var React = require('react');
var BS = require('react-bootstrap');
var _ = require('underscore');
var Rickshaw = require('rickshaw');
var palette = new Rickshaw.Color.Palette();

var BenchmarkActions = require('../actions/BenchmarkActions');
var Selector = require('./Selector.react');


var GraphEditor = React.createClass({
  propTypes: {
    actions: React.PropTypes.arrayOf(React.PropTypes.object).isRequired,
    saveUrl: React.PropTypes.string,
    onSave: React.PropTypes.func.isRequired
  },

  getInitialState: function() {
    var selectedAction = this.props.actions[0],
      selectedActionName = this._getActionName(selectedAction.uuid);

    var selectedService = null,
      selectedUnit = null,
      selectedMainMetric = null;

    if (Object.keys(selectedAction.metrics).length > 0) {
      selectedService = Object.keys(selectedAction.metrics)[0];
      selectedUnit = Object.keys(selectedAction.metrics[selectedService])[0];
      selectedMainMetric = Object.keys(selectedAction.metrics[selectedService][selectedUnit])[0];
    }

    return {
      selectedAction: selectedActionName,
      selectedService: selectedService,
      selectedUnit: selectedUnit,
      selectedMainMetric: selectedMainMetric,
      selectedSubMetric: null,
      datapoints: null
    }
  },

  _getActionName: function(uuid) {
    return uuid.slice(0, 8);
  },

  _getDottedMetricName: function(metricName) {
    var arr = [];

    if (this.props.actions.length > 1) {
      arr.push(this._getActionName(this.state.selectedAction));
    }

    return arr.concat([
      this.state.selectedService,
      this.state.selectedUnit,
      this.state.selectedMainMetric,
      metricName
    ]).join('.');
  },

  _getSelectedAction: function(action_uuid) {
    var uuid = action_uuid || this.state.selectedAction;
    var selectedAction = null;
    for (var action of this.props.actions) {
      if (this._getActionName(action.uuid) === uuid) {
        selectedAction = action;
        break;
      }
    }
    return selectedAction;
  },

  _handleSelection: function(key, val) {
    var key = 'selected' + key;
    var obj = _.clone(this.state);
    delete obj['datapoints'];
    obj[key] = val;

    if (key === 'selectedSubMetric') {
      var metricName = this._getDottedMetricName(val);
      var metricData = this._getSelectedAction().metrics
      [this.state.selectedService]
      [this.state.selectedUnit]
      [this.state.selectedMainMetric]
      [val];

      obj['datapoints'] = this.state.datapoints || {};
      obj['datapoints'][metricName] = {
        data: metricData,
        color: palette.color()
      }
    }

    obj = this._validateSelections(obj, this._getSelectedAction(obj['selectedAction']).metrics);

    this.setState(obj);
  },

  _validateSelections: function(newState, metrics) {
    var keys = ['Service', 'Unit', 'MainMetric', 'SubMetric'],
      currentKey;

    for (var i in keys) {
      currentKey = 'selected' + keys[i];
      if (!newState[currentKey] || !(newState[currentKey] in metrics)) {
        for (var j = i; j < keys.length; j++) {
          newState['selected' + keys[j]] = null;
        }
        break;
      }
      metrics = metrics[newState[currentKey]];
    }
    return newState;
  },

  _handleMetricRemoved: function(metricName) {
    var datapoints = this.state.datapoints;
    delete datapoints[metricName];
    this.setState({
      datapoints: datapoints
    });
  },

  _handleSave: function() {
    var selectedAction = this._getSelectedAction();
    $.post(
      this.props.saveUrl,
      {datapoints: JSON.stringify(this.state.datapoints)},
      this.props.onSave
    );
    this.props.onRequestHide();
  },

  _handleCancel: function() {
    this.props.onRequestHide();
  },

  componentDidUpdate: function() {
    // nothing to do if graph not in DOM
    if (!this.refs.chart) {
      return;
    }

    // clear existing graph before rerendering
    var graphNode = this.refs.chart.getDOMNode();
    var y_axis = this.refs.y_axis.getDOMNode();
    graphNode.innerHTML = '';
    y_axis.innerHTML = '';

    // no datapoints = nothing to render
    if (!this.state.datapoints || _.keys(this.state.datapoints).length === 0) {
      return;
    }

    var graph = new Rickshaw.Graph({
        element: graphNode,
        width: 580,
        height: 250,
        renderer: 'line',
        series: _.map(this.state.datapoints, function(obj, name) {
          return {
            name: name,
            color: obj.color,
            data: obj.data
          }
        })
    });
    var x_axis = new Rickshaw.Graph.Axis.Time({graph: graph});
    var y_axis = new Rickshaw.Graph.Axis.Y( {
        graph: graph,
        orientation: 'left',
        tickFormat: Rickshaw.Fixtures.Number.formatKMBT,
        element: y_axis
    } );
    graph.render();
  },

  render: function() {
    var self = this;
    var metricsAvailable = false;
    var metrics = {};
    for (var action of this.props.actions) {
      metrics[this._getActionName(action.uuid)] = action.metrics;
      if (action.metrics) {
        metricsAvailable = true;
      }
    }
    if (!metricsAvailable) {
      //return null;
    }

    return (
    <div className="launch-form">
      <div className="graph-editor">
        <BS.Panel>
          {this.props.actions.length > 1 &&
          <Selector
            values={_.keys(metrics).sort()}
            selected={this.state.selectedAction}
            onSelect={this._handleSelection.bind(this, 'Action')}
            label="Benchmarks"
          />
          }
          {this.state.selectedAction &&
          <Selector
            values={_.keys(metrics[this.state.selectedAction]).sort()}
            selected={this.state.selectedService}
            onSelect={this._handleSelection.bind(this, 'Service')}
            label="Services"
          />
          }
          {this.state.selectedService &&
            <Selector
              values={_.keys(metrics[this.state.selectedAction][this.state.selectedService]).sort()}
              selected={this.state.selectedUnit}
              onSelect={this._handleSelection.bind(this, 'Unit')}
              label="Units"
              format={(val) => `${this.state.selectedService}/${val}`}
            />
          }
          {this.state.selectedUnit &&
            <Selector
              values={_.keys(metrics[this.state.selectedAction][this.state.selectedService][this.state.selectedUnit]).sort()}
              selected={this.state.selectedMainMetric}
              onSelect={this._handleSelection.bind(this, 'MainMetric')}
              label="Category"
            />
          }
          {this.state.selectedMainMetric &&
            <Selector
              values={_.filter(_.keys(metrics[this.state.selectedAction][this.state.selectedService][this.state.selectedUnit][this.state.selectedMainMetric]), function(val) {
                return !_.contains(_.keys(self.state.datapoints), self._getDottedMetricName(val));
              }).sort()}
              selected={this.state.selectedSubMetric}
              onSelect={this._handleSelection.bind(this, 'SubMetric')}
              label="Metric"
            />
          }
          <div className="graph">
            {(!this.state.datapoints || _.keys(this.state.datapoints).length === 0) &&
              <p>Click on Metric names to populate your graph.</p>
            }
            <div className="y_axis" ref="y_axis"></div>
            <div className="chart" ref="chart"></div>
          </div>
          <div className="clear">
            {this.state.datapoints &&
              <Selector
                values={_.keys(this.state.datapoints)}
                onSelect={this._handleMetricRemoved}
                icon='remove'
                colors={_.mapObject(this.state.datapoints, function(obj, name) {
                  return obj.color;
                })}
              />
            }
          </div>
        </BS.Panel>
      </div>
      <div className="divide"></div>
      <div>
        <BS.ButtonToolbar>
          <BS.Button onClick={this._handleSave} bsStyle="primary">Save</BS.Button>
          <BS.Button onClick={this._handleCancel}>Cancel</BS.Button>
        </BS.ButtonToolbar>
      </div>
    </div>
    );
  }
});

var GraphList = React.createClass({
  propTypes: {
    graphs: React.PropTypes.object,
    onDelete: React.PropTypes.func.isRequired
  },

  _handleDelete: function(graph_id) {
    BenchmarkActions.deleteGraph(this.props.action.uuid, graph_id);
  },

  render: function() {
    var self = this;
    var graphs = this.props.graphs;
    var graphIds = Object.keys(graphs || {}).sort();

    if (graphIds.length === 0) {
      return null;
    }

    return (
      <div>
        <h2>Graphs</h2>
        {graphIds.map(function(id, i) {
          return (
            <Graph
              key={id}
              onDelete={self.props.onDelete.bind(self, id)}
              graph={graphs[id]} />
          );
        })}
        <div className="clearfix"></div>
      </div>
    );
  }
});


var Graph = React.createClass({
  propTypes: {
    graph: React.PropTypes.object.isRequired,
    onDelete: React.PropTypes.func.isRequired
  },

  getInitialState: () => {
    return {
      showButtonBar: false
    }
  },

  componentDidMount: function() {
    var graphNode = this.refs.chart.getDOMNode();
    var y_axis = this.refs.y_axis.getDOMNode();
    var graph = new Rickshaw.Graph({
        element: graphNode,
        width: 480,
        height: 250,
        renderer: 'line',
        series: _.map(this.props.graph.datapoints, function(obj, name) {
          return {
            name: name,
            color: obj.color,
            data: obj.data
          }
        })
    });
    var x_axis = new Rickshaw.Graph.Axis.Time({graph: graph});
    var y_axis = new Rickshaw.Graph.Axis.Y( {
        graph: graph,
        orientation: 'left',
        tickFormat: Rickshaw.Fixtures.Number.formatKMBT,
        element: y_axis
    } );
    graph.render();
  },

  _handleMouseEnter: function() {
    this.setState({
      showButtonBar: true
    });
  },

  _handleMouseLeave: function() {
    this.setState({
      showButtonBar: false
    });
  },

  _handleDelete: function() {
    this.props.onDelete();
  },

  render: function() {
    return (
      <div className="graph"
        onMouseEnter={this._handleMouseEnter}
        onMouseLeave={this._handleMouseLeave}>
        <div className="y_axis" ref="y_axis"></div>
        <div className="chart" ref="chart"></div>
        <div className="clear">
          {this.props.graph.datapoints &&
            <Selector
              values={_.keys(this.props.graph.datapoints)}
              onSelect={() => {}}
              colors={_.mapObject(this.props.graph.datapoints, function(obj, name) {
                return obj.color;
              })}
            />
          }
        </div>
        {this.state.showButtonBar &&
        <BS.ButtonToolbar>
          <BS.Button bsStyle='primary'
            bsSize='xsmall'
            onClick={this._handleDelete}
          >Delete Graph</BS.Button>
        </BS.ButtonToolbar>
        }
      </div>
    );
  }
});

module.exports = {
  GraphEditor: GraphEditor,
  GraphList: GraphList,
  Graph: Graph
}
