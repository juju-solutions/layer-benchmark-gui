var React = require('react');
var Router = require('react-router');
var BS = require('react-bootstrap');

var Link = Router.Link;

var Dot = require('./Dot.react');

var Utils = require('../utils/Utils');
var cx = require('classnames');

var BenchmarkRow = React.createClass({

  handleChecked: function(event) {
    var func = event.target.checked ?
      this.props.onBenchmarkSelected :
      this.props.onBenchmarkDeselected;

    func(this.props.action.uuid);
  },

  render: function() {
    var a = this.props.action;

    return (
      <tr
        className={cx(this.props.best ? 'best' : null,
                      this.props.highlighted ? 'highlight' : null)}
        onMouseOver={this.props.onMouseOver}
        onMouseOut={this.props.onMouseOut}
        onClick={this.props.onClick}
      >

        <td>
          <input
            type="checkbox"
            name="compare"
            value={a.uuid}
            onChange={this.handleChecked}
            onClick={this.props.onCheckboxClick}
            checked={this.props.selected}
          />
        </td>
        <td>
          <Link to="action" params={a} title={a.tags.join(', ')}>
            {a.charm}:{a.name}
          </Link>
        </td>
        <td className="lead">
          <Dot className={cx(Utils.statusColor(a.status))}
             title={a.status} />
        </td>
        {this.props.environmentCount > 1 &&
        <td>{a.environment ? a.environment.name: ''}</td>
        }
        <td>{a.unit}</td>
        <td>
          {a.output && a.output.meta &&
            Utils.formatResult(a.output.meta.composite)
          }
        </td>
        <td>{a.duration}</td>
        <td>{Utils.timeDeltaHtml(a.started)}</td>
      </tr>
    );
  }

});

module.exports = BenchmarkRow;
