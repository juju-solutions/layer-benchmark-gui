var React = require('react');
var Router = require('react-router');
var BS = require('react-bootstrap');
var _ = require('underscore');
var Rickshaw = require('rickshaw');
var palette = new Rickshaw.Color.Palette();
var TagsInput = require('react-tagsinput');

var cx = require('classnames');

var BenchmarkStore = require('../stores/BenchmarkStore');
var BenchmarkActions = require('../actions/BenchmarkActions');
var Header = require('./Header.react');
var Dot = require('./Dot.react');
var Graph = require('./Graph.react');
var ActionButton = require('./ActionButton.react');
var Utils = require('../utils/Utils');


var BenchmarkDetail = React.createClass({
  contextTypes: {
    router: React.PropTypes.func
  },

  getInitialState: function() {
    return {
      graphEditorVisible: false
    }
  },

  componentWillMount: function() {
    BenchmarkActions.refreshGraphs(this.context.router.getCurrentParams().uuid);
    BenchmarkActions.refreshMetrics(this.context.router.getCurrentParams().uuid);
  },

  _onGraphSave: function() {
    BenchmarkActions.refreshGraphs(this.context.router.getCurrentParams().uuid);
  },

  _handleTagAdd: function(action_uuid, tag) {
      this._saveTags(action_uuid, this.refs.tags.getTags());
  },

  _handleTagRemove: function(action_uuid, tag) {
      var tags = this.refs.tags.getTags();
      var pos = tags.indexOf(tag);
      if (pos > -1) {
        tags.splice(pos, 1);
      }
      this._saveTags(action_uuid, tags);
  },

  _saveTags: function(action_uuid, tags) {
    BenchmarkActions.updateBenchmarkTags(action_uuid, tags);
  },

  _toggleGraphEditor: function(event, show) {
    this.setState({
      graphEditorVisible: show
    });
    if (event) {
      event.preventDefault();
    }
  },

  _handlePublish: function(action) {
    var url = `/api/actions/${action.uuid}/publish`;
    $.ajax({
      url: url,
      type: 'POST',
      success: function(data) {
        alert('Benchmark published!');
      },
      error: function(xhr, status, err) {
        alert("Couldn't publish benchmark: " + err);
      }
    });
    return false;
  },

  render: function() {
    var uuid = this.context.router.getCurrentParams().uuid;
    var a = BenchmarkStore.get(uuid);

    return (
      <div>
        <Header>
          <ActionButton>
            <BS.MenuItem
              onClick={(e) => this._toggleGraphEditor(e, true)}
            >Add Graph</BS.MenuItem>
            <BS.MenuItem>
              <a href={BenchmarkStore.getSettings().graphite_url}
                  target="_blank"
              >Graphite Browser</a>
            </BS.MenuItem>
            {BenchmarkStore.getSettings().can_publish &&
             a.duration && a.bundle &&
              <BS.MenuItem
                onClick={() => this._handlePublish(a)}
              >Publish to cloud-benchmarks.org</BS.MenuItem>
            }
          </ActionButton>
          <h1>
            <Dot className={cx(Utils.statusColor(a.status))} />
            {a.service}:{a.action.name} ({a.uuid.slice(0, 8)})
          </h1>
          {this.state.graphEditorVisible &&
            <Graph.GraphEditor
              actions={[a]}
              saveUrl={`/actions/${a.uuid}/graphs`}
              onSave={this._onGraphSave}
              onRequestHide={() => this._toggleGraphEditor(null, false)}
            />
          }
        </Header>
        <BS.Grid>
          <BS.Row>
            <BS.Col md={6}>
              <Parameters action={a} />
              <Results action={a} />
            </BS.Col>
            <BS.Col md={6}>
              <Bundle action={a} />
            </BS.Col>
          </BS.Row>
          <div className="form-group parameters">
            <h2>Tags</h2>
            <TagsInput
              ref='tags'
              defaultValue={a.tags}
              onTagAdd={this._handleTagAdd.bind(this, a.uuid)}
              onTagRemove={this._handleTagRemove.bind(this, a.uuid)}
            />
          </div>
          <Graph.GraphList
            graphs={a.graphs}
            onDelete={(graph_id) => {
              BenchmarkActions.deleteGraph(a.uuid, graph_id);
            }}
          />
          <ActionProfile
            action={a}
          />
        </BS.Grid>
      </div>
    );
  }
});

var ActionProfile = React.createClass({
  propTypes: {
    action: React.PropTypes.object.isRequired
  },

  getInitialState: function() {
    return {
      selectedProfile: null
    };
  },

  handleProfileChange: function(profile) {
    this.setState({
      selectedProfile: profile
    });
  },

  render: function() {
    return (
      <div>
        <Utils.UnitProfileChooser
          action={this.props.action}
          onChange={this.handleProfileChange}
        />
        {this.state.selectedProfile &&
          <Profile profile={this.state.selectedProfile} />
        }
      </div>
    );
  }
});

var Profile = React.createClass({
  propTypes: {
    profile: React.PropTypes.object.isRequired
  },

  getInitialState: function() {
    var profile = this.props.profile;
    var selectedProfile = null;
    var profileNames = [];
    if (profile.hardware) {
      profileNames.push("hardware");
      selectedProfile = "hardware";
    }
    Object.keys(profile.packages).map(function(i) {
      if (profile.packages[i].length) {
        profileNames.push(i);
      }
    });

    if (profileNames && !selectedProfile) {
      selectedProfile = profileNames[0];
    }

    return {
      selectedProfile: selectedProfile,
      profileNames: profileNames.sort()
    };
  },

  handleProfileChange: function(event) {
    this.setState({
      selectedProfile: event.target.value
    });
  },

  render: function() {
    var profile = this.props.profile;
    var profileNames = this.state.profileNames;
    var selectedProfile= this.state.selectedProfile;

    if (!profileNames) {
      return null;
    }

    return (
      <BS.Grid>
        <BS.Row>
          <BS.Col md={12}>
            <select onChange={this.handleProfileChange} defaultValue={selectedProfile}>
            {profileNames.map(function(i) {
              return (
                <option value={i} key={i}>{i}</option>
              );
            })};
            </select>

            {selectedProfile == "hardware" &&
            <div>
              <h2>Hardware</h2>
              <table>
                <tbody>
                {profile.hardware &&
                 Object.keys(profile.hardware).sort().map(function(j) {
                   return Object.keys(profile.hardware[j]).sort().map(function(i) {
                      return (
                        <tr key={i}>
                          <td>{i}</td>
                          <td>{String(typeof profile.hardware[j][i] != 'undefined' ? profile.hardware[j][i] : '')}</td>
                        </tr>
                      );
                  });
                })}
                </tbody>
              </table>
            </div>
            }

            {selectedProfile != "hardware" &&
              <PackageProfile
                key={selectedProfile}
                title={selectedProfile}
                packages={profile.packages[selectedProfile]} />
            }
          </BS.Col>
        </BS.Row>
      </BS.Grid>
    );
  }
});

var PackageProfile = React.createClass({
  render: function() {
    var pkgs = this.props.packages;
    if (!pkgs || !pkgs.length) {
      return null;
    }

    return (
      <div>
        <h2>{this.props.title}</h2>
        <div>
          <table>
            <tbody>
            {_.chain(pkgs)
              .sortBy('name')
              .map(function(k) {
                return (
                  <tr>
                    <td>{k.name}</td>
                    <td>{k.version}</td>
                  </tr>
                );
              })
            }
            </tbody>
          </table>
        </div>
      </div>
    );
  }
});

var Bundle = React.createClass({
  getInitialState: function() {
    return {
      show: 'svg'
    }
  },

  componentDidMount: function() {
    var action = this.props.action;
    var bundle = action.bundle;
    if (!bundle) {
      return null;
    }

    $.ajax({
      url: `/actions/${action.uuid}/svg`,
      data: bundle,
      type: 'POST',
      processData: false,
      dataType: 'text',
      contentType: 'text/plain',
      success: function(data) {
        this.refs.svg.getDOMNode().innerHTML = data;
      }.bind(this),
      error: function(xhr, status, err) {
      }
    });
  },

  _show: function(what) {
    this.setState({show: what});
  },

  render: function() {
    var a = this.props.action;
    var toggle = this.state.show === 'bundle' ? 'svg' : 'bundle';

    if (!a.bundle) {
      return null;
    }

    return (
      <div className="bundle">
        <div className="pull-right">
          <a onClick={this._show.bind(this, toggle)}>{toggle}</a>
        </div>
        <h2>Topology</h2>
        <div
          className="yaml"
          style={{display: this.state.show !== 'bundle' ? 'none' : 'block'}}
        >
          {<pre>{a.bundle}</pre>}
        </div>
        <div
          ref="svg"
          className="svg"
          style={{display: this.state.show !== 'svg' ? 'none' : 'block'}}
        >
          <span className="glyphicon glyphicon-refresh spinning"></span>
        </div>
      </div>
    );
  }
});

var Parameters = React.createClass({
  render: function() {
    var a = this.props.action;

    if (!a.action.parameters) {
      return null;
    }

    return (
      <div>
        <h2>Parameters</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
          {_.keys(a.action.parameters).map(function(k) {
            var val = String(a.action.parameters[k]);
            return val === '' ? null : (
              <tr key={k}>
                <td>{k}</td>
                <td>{val}</td>
              </tr>
            );
          })}
          </tbody>
        </table>
      </div>
    );
  }
});


var Results = React.createClass({
  render: function() {
    var a = this.props.action;

    if (!(a.output && a.output.results)) {
      return (
        <p>No benchmark data available.</p>
      );
    }

    return (
      <div>
        <h2>Results</h2>
        <table className="results table">
          <thead>
            <tr>
              <th>Benchmark Key</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Status</td>
              <td>{a.status}</td>
            </tr>
            <tr>
              <td>Unit</td>
              <td>{a.unit}</td>
            </tr>
            {a.output && a.output.meta &&
              <tr>
                <td>Result</td>
                <td>{Utils.formatResult(a.output.meta.composite)}</td>
              </tr>
            }
            <tr>
              <td>Duration</td>
              <td>{a.duration}</td>
            </tr>
            <tr>
              <td>Started</td>
              <td>{Utils.timeDeltaHtml(a.started)}</td>
            </tr>
            {_.keys(a.output.results).map(function(k) {
              return (
                <tr key={k}>
                  <td>{k}</td>
                  <td>{Utils.formatResult(a.output.results[k])}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }
});


module.exports = BenchmarkDetail;
