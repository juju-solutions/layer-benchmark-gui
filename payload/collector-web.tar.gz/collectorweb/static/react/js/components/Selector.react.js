var React = require('react');
var BS = require('react-bootstrap');

var Selector = React.createClass({
  propTypes: {
    values: React.PropTypes.arrayOf(React.PropTypes.string).isRequired,
    onSelect: React.PropTypes.func.isRequired,
    selected: React.PropTypes.string,
    label: React.PropTypes.string,
    icon: React.PropTypes.string,
    colors: React.PropTypes.object,
    format: React.PropTypes.func
  },

  getDefaultProps: function() {
    return {
      format: (val) => val
    };
  },

  _handleSelect: function(val, event) {
    this.props.onSelect(val);
    event.preventDefault();
  },

  render: function() {
    var self = this;

    return (
      <nav>
      <ul className="nav nav-pills">
      {self.props.label &&
        <label>{self.props.label}</label>
      }
      {self.props.values.map(function(val) {
        var styles = {};
        if (self.props.colors) {
          styles['color'] = 'white';
          styles['backgroundColor'] = self.props.colors[val];
        }
        return (
          <li
            className={(val === self.props.selected) ? 'active' : ''}
            key={val}>
            <a
              onClick={self._handleSelect.bind(self, val)}
              style={styles}>
              {self.props.icon &&
                <BS.Glyphicon glyph={self.props.icon} />
              }
              {self.props.format(val)}
            </a>
          </li>
        );
      })}
      </ul>
      </nav>
    );
  }
});


module.exports = Selector;
