var React = require('react');

var Table = React.createClass({
  render: function() {
    return (
      <table className={this.props.className || 'table'}>
        <thead>
          <tr>
            {(this.props.cols || []).map(function(val) {
              return (
                <th>{val}</th>
              );
            })}
          </tr>
        </thead>
        {this.props.children}
      </table>
    );
  }
});

module.exports = Table;
