var React = require('react');
var Router = require('react-router');
var BS = require('react-bootstrap');
var Link = Router.Link;
var _ = require('underscore');

var BenchmarkStore = require('../stores/BenchmarkStore');
var BenchmarkActions = require('../actions/BenchmarkActions');
var ComparisonStore = require('../stores/ComparisonStore');
var ComparisonActions = require('../actions/ComparisonActions');
var Header = require('./Header.react');
var Table = require('./Table.react');
var TableRow = require('./TableRow.react');
var Graph = require('./Graph.react');

var Utils = require('../utils/Utils');


var BenchmarkCompare = React.createClass({
  mixins: [Router.State],

  getInitialState: function() {
    var from = this.getQuery().from;
    var to = this.getQuery().to;
    var id = [from, to].sort().join('-');
    return {
      from: from,
      to: to,
      id: id,
      comparison: null
    }
  },

  componentWillMount: function() {
    ComparisonActions.refresh(this.state.id);
    for (var uuid of [this.state.from, this.state.to]) {
      BenchmarkActions.refreshMetrics(uuid);
    }
  },

  componentDidMount: function() {
    ComparisonStore.addChangeListener(this._onChange);
  },

  componentWillUnmount: function() {
    ComparisonStore.removeChangeListener(this._onChange);
  },

  _onChange: function() {
    this.setState({
      comparison: ComparisonStore.get(this.state.id)
    });
  },

  _onGraphSave: function() {
    ComparisonActions.refresh(this.state.id);
  },

  render: function() {
    var from = BenchmarkStore.get(this.state.from);
    var to = BenchmarkStore.get(this.state.to);

    var from_results = this.ensureResults(from);
    var to_results = this.ensureResults(to);

    return (
      <div>
        <Header>
          <BS.ModalTrigger modal={
            <Graph.GraphEditor
              actions={[from, to]}
              saveUrl={`/api/comparisons/${this.state.id}/graphs`}
              onSave={this._onGraphSave}
            />
          }>
            <BS.Button
              bsStyle='primary'
              className="pull-right btn-launch"
            >Add Graph</BS.Button>
          </BS.ModalTrigger>
          <h1>Benchmark Comparison</h1>
        </Header>
        <BS.Grid>
          <Table cols={['',
              <h3>
                <Link to="action" params={from}>
                  {from.uuid.slice(0, 8)}
                </Link>
              </h3>,
              <h3>
                <Link to="action" params={to}>
                  {to.uuid.slice(0, 8)}
                </Link>
              </h3>,
          ]}>
            <TableRow cols={["Status", from.status, to.status]} />
            <TableRow cols={["Unit", from.unit, to.unit]} />
            <TableRow cols={["Started", from.started, to.started]} />
            <TableRow cols={["Duration", from.duration, to.duration]} />
            {_.union(_.keys(from_results),
                     _.keys(to_results)).map(function(k) {
              return k == 'raw' ? null : (
                <TableRow cols={[k,
                  Utils.formatResult(from_results[k]),
                  Utils.formatResult(to_results[k])
                ]}/>
              );
            })}
          </Table>

          {this.state.comparison &&
          <Graph.GraphList
            graphs={this.state.comparison.graphs}
            onDelete={(graph_id) => {
              ComparisonActions.deleteGraph(this.state.id, graph_id);
            }}
          />
          }

          <ProfileCompare from={from} to={to} />

          <div className="clear">
            <a href={BenchmarkStore.getSettings().graphite_url}
                target="_blank"
                className="btn btn-link">Graphite Browser</a>
          </div>
        </BS.Grid>
      </div>
    );
  },

  ensureResults: function(benchmark) {
    return (
      benchmark.output && benchmark.output.results ?
        benchmark.output.results :
        {}
    );
  }
});

var ActionLink = React.createClass({
  propTypes: {
    action: React.PropTypes.object.isRequired
  },

  render: function() {
    return (
      <Link to="action" params={this.props.action}>
        {this.props.action.uuid}
      </Link>
    );
  }
});

var ProfileCompare = React.createClass({
  propTypes: {
    from: React.PropTypes.object.isRequired,
    to: React.PropTypes.object.isRequired
  },

  render: function() {
    var from = this.props.from.profile || {};
    var to = this.props.to.profile || {};
    from.hardware = from.hardware || {};
    to.hardware = to.hardware || {};
    from.packages = from.packages || {};
    to.packages = to.packages || {};
    var hwKeys = _.union(_.keys(from.hardware), _.keys(to.hardware));
    var pkgKeys = _.union(_.keys(from.packages), _.keys(to.packages));
    var hwDiffs = _.filter(hwKeys, function(k) {
      return from.hardware[k] !== to.hardware[k];
    });
    var hwDiffHtml = hwDiffs.length ? (
      <div>
        <h2>Hardware Differences</h2>
        <table className='table'>
          <tbody>
          {hwDiffs.sort().map(function(k) {
            return (
              <tr>
                <td>{k}</td>
                <td>{String(typeof from.hardware[k] != 'undefined' ? from.hardware[k] : '')}</td>
                <td>{String(typeof to.hardware[k] != 'undefined' ? to.hardware[k] : '')}</td>
              </tr>
            );
          })}
          </tbody>
        </table>
      </div>
    ) : null;

    var pkgDiffHtml = pkgKeys.sort().map(function(k) {
      var fromPkgs = _.indexBy(from.packages[k], 'name');
      var toPkgs = _.indexBy(to.packages[k], 'name');
      var pkgNames = _.union(_.keys(fromPkgs), _.keys(toPkgs));
      var pkgDiffs = _.filter(pkgNames, function(name) {
        return (fromPkgs[name] || {}).version !== (toPkgs[name] || {}).version;
      });
      return pkgDiffs.length ? (
        <div>
          <h2>{k}</h2>
          <table className='table'>
            <tbody>
            {pkgDiffs.sort().map(function(pkgName) {
              return (
                <tr>
                  <td>{pkgName}</td>
                  <td>{(fromPkgs[pkgName] || {}).version}</td>
                  <td>{(toPkgs[pkgName] || {}).version}</td>
                </tr>
              );
            })}
            </tbody>
          </table>
        </div>
      ) : null;
    });

    return (
      <div>
        {hwDiffHtml}
        {pkgDiffHtml}
      </div>
    );

  }
});

module.exports = BenchmarkCompare;
