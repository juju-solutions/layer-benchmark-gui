var React = require('react');
var BS = require('react-bootstrap');
var BenchmarkRow = require('./BenchmarkRow.react');
var _ = require('underscore');

var cx = require('classnames');
var Utils = require('../utils/Utils');
var Dot = require('./Dot.react');

const SORT_DESC = -1;
const SORT_ASC = 1;
const SORT_NONE = 0;


var BenchmarkTable = React.createClass({

  getInitialState: function() {
    return {
      comparing: false,
      comparisonGroup: [],
      bestResult: null,
      stickyCompare: null,
      sortCol: 'Started',
      sortDir: SORT_DESC,
      sortFunc: (a) => a.started || ''
    }
  },

  _getBestResult: function(actions) {
    actions = _.filter(actions, function(action) {
      return action.output &&
             action.output.meta &&
             action.output.meta.composite;
    });

    if (actions.length === 0) {
      return null;
    }

    actions = _.sortBy(actions, function(action) {
      return action.output.meta.composite.value;
    });

    var chooser = _.first;
    var sorters = _.countBy(actions, function(action) {
      return action.output.meta.composite.direction;
    });

    if (sorters) {
      var most = _.max(_.values(sorters));
      for (var sorter in sorters) {
        if (sorters[sorter] === most) {
          chooser = sorter.toLowerCase() === 'desc' ? _.last : chooser;
          break;
        }
      }
    }

    return chooser(actions).uuid;
  },

  _setComparison: function(action, sticky) {
    var comparisonGroup = _.filter(this.props.data, function(a) {
      return (a.service === action.service &&
              a.name === action.name);
    });

    this.setState({
      comparing: true,
      comparisonGroup: _.pluck(comparisonGroup, 'uuid'),
      bestResult: this._getBestResult(comparisonGroup),
      stickyCompare: sticky ? action.uuid : null
    });
  },

  _handleRowMouseOver: function(hoverAction) {
    if (this.state.stickyCompare) {
      return;
    }

    this._setComparison(hoverAction, false);
  },

  _handleRowMouseOut: function(action) {
    if (this.state.stickyCompare) {
      return;
    }

    this.setState({
      comparing: false,
      comparisonGroup: [],
      bestResult: null
    });
  },

  _handleRowClick: function(action) {
    if (this.state.stickyCompare &&
        _.contains(this.state.comparisonGroup, action.uuid)) {
      this.setState({
        comparing: false,
        comparisonGroup: [],
        bestResult: null,
        stickyCompare: null
      });
    }
    else {
      this._setComparison(action, true);
    }
  },

  _handleCheckboxClick: function(event) {
    if (this.state.stickyCompare) {
      event.stopPropagation();
    }
  },

  _getSortDir: function(col) {
    if (this.state.sortCol === col) {
      return this.state.sortDir;
    }
    return SORT_NONE;
  },

  _handleSort: function(col, dir, func) {
    this.setState({
      sortCol: col,
      sortDir: dir,
      sortFunc: func
    });
  },

  _makeColumnHeader: function(name, sortFunc) {
    return (
      <ColumnHeader
        name={name}
        sortDir={this._getSortDir(name)}
        sortFunc={sortFunc}
        onSort={this._handleSort}
      />
    );
  },

  render: function() {
    var p = this.props;
    var sortedData = _.sortBy(p.data, this.state.sortFunc);

    if (this.state.sortDir === SORT_DESC) {
      sortedData = sortedData.reverse();
    }

    var benchmarkRows = sortedData
      .map(function (action) {
        var highlighted =
          !this.state.comparing ||
          _.contains(this.state.comparisonGroup, action.uuid);

        return (
          <BenchmarkRow
            key={action.uuid}
            action={action}
            onBenchmarkSelected={p.onBenchmarkSelected}
            onBenchmarkDeselected={p.onBenchmarkDeselected}
            selected={_.contains(p.selectedBenchmarks, action.uuid)}
            highlighted={highlighted && (this.state.comparing || this.state.stickyCompare)}
            best={this.state.bestResult === action.uuid}
            onMouseOver={this._handleRowMouseOver.bind(this, action)}
            onMouseOut={this._handleRowMouseOut.bind(this, action)}
            onClick={this._handleRowClick.bind(this, action)}
            onCheckboxClick={this._handleCheckboxClick}
          />
        );
    }.bind(this));

    return (
      <div>
        <table className="table">
          <thead>
            <tr>
              <ColumnHeader sortable={false}><input type="checkbox"/></ColumnHeader>
              {this._makeColumnHeader('State', (a) => a.status)}
              {this._makeColumnHeader('Benchmark', (a) => `${a.service}:${a.name}`)}
              {this._makeColumnHeader('Unit', (a) => a.unit)}
              {this._makeColumnHeader('Result', function(a) {
                if (a.output &&
                    a.output.meta &&
                    a.output.meta.composite) {
                  return a.output.meta.composite.value;
                }
                return null;
              })}
              {this._makeColumnHeader('Duration', (a) => a.duration)}
              {this._makeColumnHeader('Started', (a) => a.started)}
            </tr>
          </thead>
          <tbody>
            {p.launchPending &&
            <tr>
              <td>
                <span className="glyphicon glyphicon-refresh spinning"></span>
              </td>
              <td className="lead">
                <Dot className={cx(Utils.statusColor("pending"))}
                   title="pending" />
              </td>
              <td>Launching...</td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
            }
            {benchmarkRows}
          </tbody>
        </table>
      </div>
    );
  }
});

var ColumnHeader = React.createClass({
  propTypes: {
    name: React.PropTypes.string,
    sortable: React.PropTypes.bool,
    sortDir: React.PropTypes.number,
    sortFunc: React.PropTypes.func,
    onSort: React.PropTypes.func
  },

  getDefaultProps: function() {
    return {
      name: null,
      sortable: true,
      sortDir: SORT_NONE,
      sortFunc: undefined
    }
  },

  _handleClick: function() {
    if (!this.props.sortable) {
      return;
    }

    var sortDir = this.props.sortDir === SORT_NONE ?
      SORT_DESC :
      -this.props.sortDir;
    this.props.onSort(this.props.name, sortDir, this.props.sortFunc);
  },

  render: function() {
    return (
      <th
        onClick={this._handleClick}
        className={cx(this.props.sortable ? 'sortable' : false)}
      >
        {this.props.name || this.props.children}
        {this.props.sortDir === SORT_DESC &&
            <BS.Glyphicon glyph='triangle-bottom' />}
        {this.props.sortDir === SORT_ASC &&
            <BS.Glyphicon glyph='triangle-top' />}
      </th>
    );
  }
});

module.exports = BenchmarkTable;
