var AppDispatcher = require('../dispatcher/AppDispatcher');
var ComparisonConstants = require('../constants/ComparisonConstants');

var ComparisonActions = {

  refresh: function(id) {
    AppDispatcher.dispatch({
      actionType: ComparisonConstants.COMPARISON_REFRESH,
      comparison_id: id
    });
  },

  deleteGraph: function(comparison_id, graph_uuid) {
    AppDispatcher.dispatch({
      actionType: ComparisonConstants.COMPARISON_DELETE_GRAPH,
      comparison_id: comparison_id,
      graph_uuid: graph_uuid
    });
  }

};

module.exports = ComparisonActions;
