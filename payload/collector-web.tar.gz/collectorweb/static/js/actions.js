$(document).ready(function(){
  $('.filter.menu .item').tab();
  $('.unit.menu .item').tab();
  $('.ui.sidebar').sidebar('attach events', '.launch.button');
  $('.ui.dropdown').dropdown();
  $('.ui.checkbox').checkbox();
  $('.inbox .item').click(function() {
    var tag = $(this).data('tag');
    var self = $(this);
    $('.benchmark.result .dimmer').addClass('active');
    $.get('/actions/' + tag, function(data) {
      $('.item.active').removeClass('active');
      $('#action-data').html(data);
      self.addClass('active');
      $('.benchmark.result .dimmer').removeClass('active');
    });
  });
  $('.inbox .item').first().click();
  $('.ui.launch.button').click(function() {
    $('.launch.modal').modal('show');
  });
  $('div.launch a.benchmark.label').click(function() {
    var benchmark = $(this).data('benchmark');
    $('div.launch a.benchmark.black').removeClass('black');
    $('div.launch div.detail').hide();
    $('div.launch div.detail[data-benchmark=' + benchmark + ']').show();
    $(this).addClass('black');
    $('.modal').modal('refresh');
  });
});
