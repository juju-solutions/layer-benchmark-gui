from pyramid.view import view_config
from pyramid.response import Response

from socketio.namespace import BaseNamespace
from socketio import socketio_manage
from socketio.mixins import BroadcastMixin

import gevent
from gevent import Greenlet
from gevent.queue import Queue, Empty

handlers = []


class Actor(gevent.Greenlet):

    def __init__(self):
        self.inbox = Queue()
        Greenlet.__init__(self)

    def receive(self, message):
        """
        Define in your subclass.
        """
        raise NotImplemented()

    def _run(self):
        self.running = True

        while self.running:
            try:
                message = self.inbox.get_nowait()
                self.receive(message)
            except Empty:
                pass
            gevent.sleep(0)


class JujuHandler(Actor):
    def __init__(self, namespace):
        super(JujuHandler, self).__init__()
        self.namespace = namespace
        self.start()

    def receive(self, message):
        self.namespace.emit("event", message)


def juju_api_listener(settings):
    from jujuclient import Environment
    env = Environment(settings['juju.api.endpoint'])
    env.login(settings['juju.api.secret'],
              settings['juju.api.user'])

    watch = env.get_watch()
    for msg in watch:
        for handler in handlers:
            handler.inbox.put_nowait(msg)
        gevent.sleep(0)


class EventsNamespace(BaseNamespace, BroadcastMixin):
    def initialize(self):
        self.juju_handler = JujuHandler(self)
        handlers.append(self.juju_handler)

    def on_event(self, msg):
        self.broadcast_event('event', msg)

    def recv_connect(self):
        self.broadcast_event('user_connect')

    def recv_disconnect(self):
        handlers.remove(self.juju_handler)
        self.broadcast_event('user_disconnect')
        self.disconnect(silent=True)


@view_config(route_name='live', renderer='live.mako')
def live(request):
    """ Base view to load our single-page-app template """
    return {}


@view_config(route_name='socket_io')
def socketio_service(request):
    socketio_manage(request.environ,
                    {'/events': EventsNamespace},
                    request=request)

    return Response('')
