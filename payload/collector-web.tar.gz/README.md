Pyramid webapp that displays Juju benchmark data from Redis.

Use the
[collector-worker](https://github.com/juju-solutions/collector-worker)
to populate Redis from the Juju API.

# Installation

    git clone https://github.com/juju-solutions/collector-web
    cd collector-web
    python setup.py install

To run tests:

    make test

# Usage

Update `production.ini` with your Redis and Graphite server info, then:

    pserve production.ini

Browse to http://localhost:6543/actions

# API

## GET /api/actions

Get list of all completed or pending actions.

    $ curl -s http://localhost:6543/api/actions | python -m json.tool
    {
        "actions": [
            {
                "actions": [
                    {
                        "action": {
                            "name": "smoke",
                            "receiver": "unit-pts-0",
                            "tag": "action-876a38c4-2ea2-4458-8b4e-a5e78499e3d8"
                        },
                        "output": {
                            "meta": {
                                "start": "2015-01-13T17:00:27Z",
                                "stop": "2015-01-13T17:00:43Z"
                            }
                        },
                        "status": "completed"
                    }
                ],
                "receiver": "unit-pts-0"
            }
        ]
    }

## GET /api/benchmarks

Same as `/api/actions`, but only returns benchmark actions. To define
which actions are benchmarks, see the `POST /api/services/:service` api.

## GET /api/actions/:uuid

Get result data for a specific action.

    $ curl -s http://localhost:6543/api/actions/f3c00159-08b4-42c2-8892-0d0b71f78575 | python -m json.tool
    {
        "action": {
            "name": "smoke",
            "receiver": "unit-pts-0",
            "tag": "action-876a38c4-2ea2-4458-8b4e-a5e78499e3d8"
        },
        "output": {
            "meta": {
                "start": "2015-01-13T17:00:27Z",
                "stop": "2015-01-13T17:00:43Z"
            }
        },
        "status": "completed"
    }

## POST /api/units/:service/:unit?[action=:uuid]

Save unit profiling data.

    $ curl -s http://localhost:6543/api/units/pts/0 -H "Content-Type: application/json" -d '{"foo":"bar"}'

Save unit profiling data for a specific action.

    $ curl -s http://localhost:6543/api/units/pts/0?action=876a38c4-2ea2-4458-8b4e-a5e78499e3d8 -H "Content-Type: application/json" -d '{"foo":"baz"}'

## GET /api/units/:service/:unit?[action=:uuid]

Get all profiling data for a unit.

    $ curl -s http://localhost:6543/api/units/pts/0 | python -m json.tool
    [
        {
            "action": null,
            "data": {
                "foo": "bar"
            },
            "timestamp": "2015-01-27T14:35:38Z"
            "status": { ... }
        },
        {
            "action": "876a38c4-2ea2-4458-8b4e-a5e78499e3d8",
            "data": {
                "foo": "baz"
            },
            "timestamp": "2015-01-27T14:37:42Z"
            "status": { ... }
        }
    ]

Get profiling data for a specific action on a unit.

    $ curl -s http://localhost:6543/api/units/pts/0?action=876a38c4-2ea2-4458-8b4e-a5e78499e3d8 | python -m json.tool
    [
        {
            "action": "876a38c4-2ea2-4458-8b4e-a5e78499e3d8",
            "data": {
                "foo": "baz"
            },
            "timestamp": "2015-01-27T14:37:42Z"
            "status": { ... }
        }

The `status` key contains a snapshot of `juju status` at the time the
profiling data was saved.
    ]

## POST /api/services/:service

Define which actions are benchmarks for a service.

    $ curl -s http://localhost:6543/api/services/pts -H "Content-Type: application/json" -d '{"benchmarks": ["smoke"]}'

## GET /api/services/:service

Retrieve service data that was POSTed.

    $ curl -s http://localhost:6543/api/services/pts | python -m json.tool
    {
        "benchmarks": [
            "smoke"
        ]
    }
