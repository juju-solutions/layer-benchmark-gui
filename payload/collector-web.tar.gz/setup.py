from setuptools import setup

requires = [
    'pyramid',
    'pyramid_mako',
    'pyramid_debugtoolbar',
    'gevent-socketio',
    'gevent-websocket',
    'gevent',
    'waitress',
    'jujuclient',
    'redis',
    'requests',
    'nose',
    'coverage',
    'flake8',
    'mock',
    'python-dateutil',
    'humanize',
    'pytz',
    'pyyaml',
    ]

setup(name='collectorweb',
      version='0.1.0',
      install_requires=requires,
      url='http://github.com/juju-solutions/collector-web',
      packages=['collectorweb'],
      include_package_data=True,
      zip_safe=False,
      entry_points="""\
      [paste.app_factory]
      main = collectorweb:main
      """,
      )
