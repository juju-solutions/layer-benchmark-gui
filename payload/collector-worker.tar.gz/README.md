The `collectworker` script queries a Juju API server for `juju
action` data and stores that data in Redis.

# Installation

    git clone https://github.com/juju-solutions/collector-worker
    cd collector-worker
    python setup.py install

# Usage

Run `collectworker`, passing it your Juju API secret, for example:

    collectorworker $(grep admin-secret ~/.juju/environments/local.jenv | cut -d : -f 2 | tr -d ' ')

For more options, see `collectworker -h`:

    $ collectorworker -h
    usage: collectorworker [-h] [--api-user API_USER]
                           [--api-endpoint API_ENDPOINT] [--redis-host REDIS_HOST]
                           [--redis-port REDIS_PORT] [--redis-db REDIS_DB]
                           api_secret

    positional arguments:
      api_secret            Juju API secret

    optional arguments:
      -h, --help            show this help message and exit
      --api-user API_USER   Juju API user (default: user-admin)
      --api-endpoint API_ENDPOINT
                            Juju API endpoint (default: wss://localhost:17070)
      --redis-host REDIS_HOST
                            Redis host (default: 127.0.0.1)
      --redis-port REDIS_PORT
                            Redis port (default: 6379)
      --redis-db REDIS_DB   Redis db (default: 0)

# Data Storage

## Full Results

The entire API result is stored in Redis as stringified JSON under the
`actions` key. The structure looks like this:

    {
        "actions": [
            {
                "actions": [
                    {
                        "action": {
                            "name": "smoke",
                            "receiver": "unit-pts-0",
                            "tag": "action-f3c00159-08b4-42c2-8892-0d0b71f78575"
                        },
                        "status": "completed"
                    },
                    {
                        "action": {
                            "name": "memory",
                            "receiver": "unit-pts-0",
                            "tag": "action-096ad51a-8b87-4d28-8cae-0b2eff6e028a"
                        },
                        "status": "completed"
                    }
                ],
                "receiver": "unit-pts-0"
            }
        ]
    }

To retrieve this data using redis-cli:

    $ redis-cli
    127.0.0.1:6379> get actions
    "{\"actions\": [{\"actions\": [{\"action\": {\"tag\":
    \"action-f3c00159-08b4-42c2-8892-0d0b71f78575\", \"name\": \"smoke\",
    \"receiver\": \"unit-pts-0\"}, \"status\": \"completed\"}, {\"action\":
    {\"tag\": \"action-096ad51a-8b87-4d28-8cae-0b2eff6e028a\", \"name\":
    \"memory\", \"receiver\": \"unit-pts-0\"}, \"status\": \"completed\"}],
    \"receiver\": \"unit-pts-0\"}]}"

## Individual Actions

Each individual action result is stored as stringified JSON under a key
that matches the action's tag. The structure looks like this:

    {
        "action": {
            "name": "smoke",
            "receiver": "unit-pts-0",
            "tag": "action-f3c00159-08b4-42c2-8892-0d0b71f78575"
        },
        "status": "completed"
    }

To retrieve this data using redis-cli:

    $ redis-cli
    127.0.0.1:6379> get action-f3c00159-08b4-42c2-8892-0d0b71f78575
    "{\"action\": {\"tag\": \"action-f3c00159-08b4-42c2-8892-0d0b71f78575\",
    \"name\": \"smoke\", \"receiver\": \"unit-pts-0\"}, \"status\":
    \"completed\"}"
