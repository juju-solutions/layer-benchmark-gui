import json
import unittest
from mock import patch, call


class MockActionEnvironment(object):
    data = {
        "actions": [
            {
                "actions": [
                    {
                        "action": {
                            "name": "smoke",
                            "receiver": "unit-pts-0",
                            "tag": "action-f3c00159-08b4-42c2-8892-0d0b71f78575"
                        },
                        "status": "completed"
                    }
                ],
                "receiver": "unit-pts-0"
            }
        ]
    }

    def __init__(self, *args):
        pass

    def login(self, *args, **kw):
        pass

    def actions_list_all(self):
        return self.data


class Tests(unittest.TestCase):
    def setUp(self):
        from collectorworker import collectorworker

        self.patcher = patch.object(
            collectorworker, 'ActionEnvironment', MockActionEnvironment)
        self.patcher.start()

    def tearDown(self):
        self.patcher.stop()

    @patch('collectorworker.collectorworker._get_parser')
    @patch('collectorworker.collectorworker.redis.StrictRedis.set')
    def test_main(self, redis_set, _get_parser):
        from collectorworker.collectorworker import main
        main()
        redis_set.assert_calls([
            call('actions', json.dumps(MockActionEnvironment.data)),
            call('action-f3c00159-08b4-42c2-8892-0d0b71f78575', json.dumps(
                MockActionEnvironment.data['actions'][0]['actions'][0])),
        ])
