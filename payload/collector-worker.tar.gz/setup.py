from setuptools import setup

install_requires = [
    'jujuclient',
    'redis',
    'coverage',
    'nose',
    'flake8',
    'mock',
]


setup(
    name='collectorworker',
    version='0.1.0',
    description='',
    install_requires=install_requires,
    url="https://github.com/juju-solutions/collector-worker",
    packages=['collectorworker'],
    entry_points={
        'console_scripts': [
            'collectorworker=collectorworker.collectorworker:main',
        ]
    }
)
