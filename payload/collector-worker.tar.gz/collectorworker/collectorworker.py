import argparse
import json
import sys

import redis
import jujuclient


class ActionEnvironment(jujuclient.Environment):
    def actions_list_all(self, service=None):
        args = {
            "Type": 'Action',
            "Request": 'ListAll',
            "Params": {
                "Entities": []
            }
        }

        services = self.status().get('Services', {})
        service_names = [service] if service else services
        for name in service_names:
            for unit in services[name]['Units']:
                args['Params']['Entities'].append(
                    {
                        "Tag": "unit-%s" % unit.replace('/', '-'),
                    }
                )

        return self._rpc(args)


def _get_parser():
    description = ''

    parser = argparse.ArgumentParser(
        description=description,
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument(
        'api_secret',
        help='Juju API secret',
    )
    parser.add_argument(
        '--api-user', default='user-admin',
        help='Juju API user',
    )
    parser.add_argument(
        '--api-endpoint', default='wss://localhost:17070',
        help='Juju API endpoint',
    )
    parser.add_argument(
        '--redis-host', default='127.0.0.1',
        help='Redis host',
    )
    parser.add_argument(
        '--redis-port', default='6379',
        help='Redis port',
    )
    parser.add_argument(
        '--redis-db', default=0, type=int,
        help='Redis db',
    )
    return parser


def _exit(msg, code=1):
    sys.stderr.write(msg + '\n')
    sys.exit(code)


def main():
    parser = _get_parser()
    args = parser.parse_args()

    try:
        env = ActionEnvironment(args.api_endpoint)
        env.login(args.api_secret, user=args.api_user)
    except jujuclient.EnvError as e:
        _exit("Couldn't connect to Juju API server: {}".format(e.message))

    results = env.actions_list_all()

    if results:
        try:
            r = redis.StrictRedis(
                host=args.redis_host, port=args.redis_port, db=args.redis_db)
            r.set('actions', json.dumps(results))
        except redis.exceptions.ConnectionError as e:
            _exit("Couldn't connect to redis server: {}".format(e))

        for receiver_actions in results.get('actions', []):
            for action in receiver_actions.get('actions', {}):
                uuid = action['action']['tag']
                r.set(uuid, json.dumps(action))

if __name__ == "__main__":
    main()
